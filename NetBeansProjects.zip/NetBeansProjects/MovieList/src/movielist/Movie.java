/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movielist;

/**
 *
 * @author norma
 */
class Movie {
    //Declaring instance data
    private String movieTitle;
    private String rating;
    private int year;
    private int runTime;
    
    //Method for lines 9-12
    public Movie(String title, String rating, int year, int runTime)
    {
        this.movieTitle = title;
        this.rating = rating;
        this.runTime = runTime;
        this.year = year;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public String getRating() {
        return rating;
    }

    public int getYear() {
        return year;
    }

    public int getRunTime() {
        return runTime;
    }

    public void setMovieTitle(String value) {
        movieTitle = value;
    }

    public void setRating(String value) {
        rating = value;
    }

    public void setYear(int value) {
        year = value;
    }

    public void setRunTime(int value) {
        runTime = value;
    }
    public String toString()
    {
        return "Movie title: " + movieTitle +
                "\n Rating: " + rating +
                "\n Year: " + year +
                "\n Total runtime: " + runTime;
    }
}

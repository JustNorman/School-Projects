
package movielist;

import java.util.Scanner;

public class MovieList {


    public static void main(String[] args) {
        //Asking the user what their favorite movies are
        Scanner in = new Scanner(System.in);
        String movie, rating;
        int year, runtime;
        Movie favoriteMovie;
        
        //Letting the user imput their data
        System.out.println("Please enter movie title: ");
        movie = in.nextLine();
        System.out.println("Please enter movie rating: ");
        rating = in.nextLine();
        System.out.println("Please enter movie produced: ");
        year = in.nextInt();
        System.out.println("Please enter movie total runtime: ");
        runtime = in.nextInt();
        //Turns their data into a list based on the Movie Class method
        favoriteMovie = new Movie(movie, rating, year, runtime);
        System.out.println(favoriteMovie.toString());
    }
    
}

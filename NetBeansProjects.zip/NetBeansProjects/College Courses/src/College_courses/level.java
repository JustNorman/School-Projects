/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package College_courses;

/**
 *
 * @author norma
 */
public enum level 
{
    INTRO,
    ADVANCED
}

package College_courses;

/**
 * College Course Tester
 * @author norma
 */

public class CollegeCoursestester 
{
    public static void main(String[] args) 
    {
        CollegeCourse myCourse = new CollegeCourse("Computer Programming II", "CS 232", 3, 1,level.ADVANCED);
        System.out.println(myCourse);
        
        CollegeCourse[] courses = new CollegeCourse[5];
        
        for(int i = 0; i < courses.length; i++)
        {
            courses[i] = new CollegeCourse("Intoduction to Information Technology", "CS 201" , 3, i+1, level.INTRO);
        }
        
        for(CollegeCourse course: courses)
        {
            System.out.println(course);
        }
        
        courses[4].setNumber("CS 202");
        courses[4].setSection(1);
        courses[4].setCourseLevel(level.ADVANCED);
        
        for(CollegeCourse course: courses)
        {
            System.out.println(course);
        }
        
        level 1 = level.INTRO;
        
        switch(1)
        {
            case INTRO:
                System.out.println("Intro Course(s)");
                for(CollegeCourse course: courses)
                {
                    if(course.getCourseLevel() == level.INTRO)
                        System.out.println(course);
                }
                
                break;
            case ADVANCED:
                System.out.println("Intro Course(s)");
                for(CollegeCourse course: courses)
                {
                    if(course.getCourseLevel() == level.ADVANCED)
                        System.out.println(course);
                }
            
                break;
            default:
                System.out.println("Check your level value");
        }
    }
    
}

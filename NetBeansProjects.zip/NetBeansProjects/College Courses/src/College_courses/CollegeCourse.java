package College_courses;

/**
 *
 * @author norma
 */
public class CollegeCourse 
{
    private String name;
    private String number;
    private int CreditHrs;
    private int section;
    private level courseLevel;
    
    //Constructors
    public CollegeCourse(String name, String number, int CreditHrs, int section, level courseLevel) 
    {
        this.name = name;
        this.number = number;
        this.CreditHrs = CreditHrs;
        this.section = section;
        this.courseLevel = courseLevel;
    }
    
    //Setters
    public void setName(String name) 
    {
        this.name = name;
    }

    public void setNumber(String number) 
    {
        this.number = number;
    }

    public void setCreditHrs(int CreditHrs) 
    {
        this.CreditHrs = CreditHrs;
    }

    public void setSection(int section) 
    {
        this.section = section;
    }

    public void setCourseLevel(level courseLevel) 
    {
        this.courseLevel = courseLevel;
    }
    
    //Getters
    public String getName() 
    {
        return name;
    }

    public String getNumber() 
    {
        return number;
    }

    public int getCreditHrs() 
    {
        return CreditHrs;
    }

    public int getSection() 
    {
        return section;
    }

    public level getCourseLevel() 
    {
        return courseLevel;
    }
    
    //toString
    @Override
    public String toString() 
    {
        return "CollegeCourse{" + "name=" + name + ", number=" + number + ", CreditHrs=" + CreditHrs + ", section=" + section + ", courseLevel=" + courseLevel + '}';
    }
    
    
    
    
}

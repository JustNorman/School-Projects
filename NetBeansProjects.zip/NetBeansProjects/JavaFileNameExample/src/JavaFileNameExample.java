/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author norma
 */
public class JavaFileNameExample 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        System.out.println("Something");
        
        PrintName p_name = new PrintName();
        p_name.print();
    }
    
}

class PrintName
{
    String name = "AKG";
    
    void print()
    {
        System.out.println("The author is: "+name);
    }
}




/*
Problem Statement:
Write a Program that will convert celsius
to Fahrenheit

Author: Norman
 */
import java.util.Scanner;

public class CelsiusToFahrenheit 
{
    public static void main(String[] args) 
    {
        //Step 1:Define required variables
        float celsius = 0;
        float fahrenheit = 0;
        
        //Step 2:Introduce Scanner object
        Scanner inputDevice = new Scanner(System.in);
        
        //Step 3:Get celsius value from user using Scanner object
        celsius = inputDevice.nextFloat();
        System.out.println("Enter the Celsius value: ");
        
        //Step 4:Use conversion formula
        fahrenheit = celsius * (float)1.8 + (float)32;
        
        //Step 5:Print result
        System.out.println(celsius+"deg Celsius = "+fahrenheit+" deg Fahrenheit");
    }
    
}

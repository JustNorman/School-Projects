/**
 *
 * @author norma
 */
public class Inheritance 
{
    public int bookNumber;
    public int pages;
    String title;
    
    public static void main(String[] args) 
    {
        
    }
    
}

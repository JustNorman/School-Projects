
package CollegeClub;

import java.util.Scanner;

/**
 *
 * @author norma
 */
public class CollegeClubsTester 
{
    public static void main(String[] args)
    {
        //Input
        Scanner input = new Scanner(System.in);
        
        //Array
        String [] CollegeClub = {"Level Up"};
        System.out.println(CollegeClub);
    }
}

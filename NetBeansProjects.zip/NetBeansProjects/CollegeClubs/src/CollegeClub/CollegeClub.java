package CollegeClub;

/**
 *
 * @author norma
 */
class CollegeClub 
{
    private String clubName;
    private String number;
    private int Adress;
    private String Description;
    private level ClubType; //category
    
    //Constructors
    public CollegeClub(String clubName, String number, int Adress, String Description, level ClubType) 
    {
        this.clubName = clubName;
        this.number = number;
        this.Adress = Adress;
        this.Description = Description;
        this.ClubType = ClubType;
    }
    
}

/**
 *
 * @author norma
 * 2/6/2022
 */
package heatindexcalculator;

import java.util.Scanner;

public class HeatIndexCalculator 
{
    public int temperature;
    public double humidity;
    public double heatIndex;
    
    public static void main(String[] args) 
    {
        //User Input
        Scanner input = new Scanner(System.in);
        System.out.printf("Please Enter the current temperature in degrees Fahrenheit: ");
        int currentTemp = input.nextInt();
        System.out.printf("\nPlease enter the current humidity as a percentage: ");
        double currentHumidity = input.nextDouble();
        
        /*HeatIndexCalculator heatIndex = new HeatIndexCalculator();
        double x = heatIndex.calculateHeatIndex(..,..);
        heatIndex.printHeatIndex(currentTemp,currentHumidity,x);
        */
    }
    
    public double calculateHeatIndex ( int currentTemp, double currentHumidity )
    {
        //Functions 
        int temperature = currentTemp;
        double humidity = currentHumidity;
        double answer;
        final double C1 = -42.379;
        final double C2 = 2.04901523;
        final double C3 = 10.14333127;
        final double C4 = -0.22475541;
        final double C5 = -.00683783;
        final double C6 = -5.481717E-2;
        final double C7 = 1.22874E-3;
        final double C8 = 8.5282E-4;
        final double C9 = -1.99E-6;
        int T = temperature;
        double R = humidity;
        double T2 = temperature * temperature;
        double R2 = humidity * humidity;
        
        //Math
        double answer = C1 + (C2 * T) + (C3 * R) + (C4 * T * R) + (C5 * T2) + (C6 * R2) + (C7 * T2 * R) + (C8 * T * R2) + (C9 * T2 * R2);
        return answer;
    }
    
    public void printHeatIndex( int currentTemp, double currentHumidity, double calculatedHeatIndex)
    {
        //double calculatedHeatIndex = answer;
        
        //Prints out Calculations
        System.out.println("\nAt a temperature of" + currentTemp + "and a humidity of" + currentHumidity + "percent . . .\n");
        System.out.println("\nIt feels like:" + calculatedHeatIndex + "F");
    }
}

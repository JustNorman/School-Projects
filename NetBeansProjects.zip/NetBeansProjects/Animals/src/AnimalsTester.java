/**
 *
 * @author norma
 */
public class AnimalsTester 
{
    public static void main(String[] args) 
    {
        Animal myAnimal = new Animal(5);
        myAnimal.createSound();
        
        Cow myCow = new Cow(5, "Shelly");
        myCow.createSound();
        
        Animal myDuck = new Duck(7, "Lindsey");
        myDuck.createSound();
        
        Animal[] myAnimals = {new Animal(10), new Duck(15, "Harrol"), new Cow(35, "Jonathan"), new Cow(95, "Lily")};
        
        for(Animal a: myAnimals)
        {
            a.createSound();
        }
        
        //Instanceof
        System.out.println(myCow instanceof Cow);
        System.out.println(myCow instanceof Animal);
        
    }
    
}

class Animal
{
    protected int id;
    
    public Animal(int id)
            {
                this.id = id;
            }
    
    public void createSound()
    {
        System.out.println("Animal noises");
    }
}

class Cow extends Animal
{
    String name;
    
    public Cow(int id, String name)
    {
        super(id);
        this.name = name;
    }
    
    public void createSound()
    {
        System.out.println("The cows goes moo");
    }
}

class Duck extends Animal
{
    String name;
    
    public Duck(int id, String name)
    {
        super(id);
        this.name = name;
    }
    
    public void createSound()
    {
        System.out.println("The duck goes quack");
    }
}


import java.util.Scanner;

/**
 *
 * @author norma
 */
public class Student extends Person
{
    private String mFOS; //Field of Study
    private double gpa;
    
    //Insert Getters
    public String getmFOS() 
    {
        return mFOS;
    }
    public double getGpa() 
    {
        return gpa;
    }
    
    //Insert Setters
    public void setmFOS(String mFOS) 
    {
        this.mFOS = mFOS;
    }
    public void setGpa(double gpa) 
    {
        this.gpa = gpa;
    }
    
    //Insert Constructors
    public Student(String mFOS, double gpa) 
    {
        this.mFOS = mFOS;
        this.gpa = gpa;
    }
    public Student(String mFOS, double gpa, Scanner scan) 
    {
        super(scan);
        this.mFOS = mFOS;
        this.gpa = gpa;
    }
    public Student(String mFOS, double gpa, String fName, String lName, String Adress, String zCode, String pNumber) 
    {
        super(fName, lName, Adress, zCode, pNumber);
        this.mFOS = mFOS;
        this.gpa = gpa;
    }
    
    //Note to future me: Not sure why it saying override but it works so leave it future me
    @Override
        public String getfName()
    {
        return super.getfName();
    }
    @Override
    public String getlName()
    {
        return super.getlName();
    }
    @Override
        public String getpNumber()
    {
        return super.getpNumber();
    }
    @Override
    public String getzCode()
    {
        return super.getzCode();
    }
    @Override
    public String getAdress()
    {
        return super.getAdress();
    }
    
    @Override
    public void setPhoneNumber(String pNumber) 
    {
        super.setPhoneNumber(pNumber);
    }
    @Override
    public void setZipCode(String zCode) 
    {
        super.setZipCode(zCode);
    }
    @Override
    public void setStreetAdress(String Adress) 
    {
        super.setStreetAdress(Adress);
    }
    @Override
    public void setLastName(String lName) 
    {
        super.setLastName(lName);
    }
    @Override
    public void setFirstName(String fName) 
    {
        super.setFirstName(fName);
    }
    
    //toString method
    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("\n Field of Study: ").append(this.mFOS).append(",");
        sb.append("\n GPA: ").append(this.gpa).append("\n");
        sb.append("\n Student's Details: ").append("\n");
        sb.append(this.fName).append("");
        sb.append(this.lName).append(",");
        sb.append(this.Adress).append("-");
        sb.append(this.zCode).append(",");
        sb.append("Ph: ").append(this.pNumber);
        return sb.toString();
    }
    
    public void setStudentData(Scanner scan)
    {
        String next="";
        System.out.println("Student Details: ");
        System.out.println("Student first name: ");
        next=scan.next();
        this.setFirstName(next);
        System.out.println("Student last name: ");
        next=scan.next();
        this.setLastName(next);
        System.out.println("Student street address: ");
        next=scan.next();
        this.setStreetAdress(next);
        System.out.println("Student zip code: ");
        next=scan.next();
        this.setZipCode(next);
        System.out.println("Student phone number: ");
        next=scan.next();
        this.setPhoneNumber(next);
        System.out.println("Student Field of Study: ");
        next=scan.next();
        this.setmFOS(next);
        System.out.println("Student GPA: ");
        this.setGpa(scan.nextDouble());
    }
    
    public Student(){
       
}
    public Student(Scanner scan)
    {
        setStudentData(scan);
    }
    
}


import java.util.Scanner;

/**
 *
 * @author norma
 */
public class Faculty extends CollegeEmployee
{
    protected boolean T; //Tenured
    
    public Faculty(boolean T)
    {
        this.T = T;
    }
    
    public Faculty(Scanner scan)
    {
        setFacultyData(scan);
    }
    
    public Faculty(){
    }    
    
    public Faculty(String staffld, double aSalary, String dName, boolean T)
    {
        super(staffld,aSalary,dName);
        this.T = T;
    }
    
    public Faculty(String fName, String lName, String Adress, String zCode, String pNumber, String staffld, String aSalary, String dName, boolean T)
    {
        super(fName,lName,Adress,zCode,pNumber,staffld,aSalary,dName);
        this.T = T;
    }
    
    public boolean T()
    {
        return T;
    }
    public void setTenured(boolean T)
    {
        this.T = T;
    }
    
    //Note to future me: Not sure why it saying override but it works so leave it future me
    @Override
    public double getaSalary()
    {
        return super.getaSalary();
    }
    @Override
    public String getdName()
    {
        return super.getdName();
    }
    @Override
    public void  setaSalary(double aSalary)
    {
        super.setaSalary(aSalary);
    }
    @Override
    public void setdName(String dName)
    {
        super.setdName(dName);
    }
    
    //insert toString
   /* @Override
    public String toString() {
        return "Faculty{" + "T=" + T + '}';
    }*/
    
    //Typed up toString code to see if this works or not
    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("Faculty ID: ").append(super.staffld);
        sb.append("\n");
        sb.append("Department: ").append(super.dName);
        sb.append("\n");
        sb.append("Anual Salary: ").append(super.aSalary);
        sb.append("\n");
        sb.append("Tenured: ").append((T()?"Yes":"No"));
        sb.append("\n");
        sb.append("Employee Details: ");
        sb.append("\n");
        sb.append(super.fName).append("");
        sb.append(super.lName).append(",");
        sb.append(super.Adress).append("-");
        sb.append(super.zCode).append(",");
        sb.append("Ph:").append(super.pNumber);
        return sb.toString();
    }
    
    public void setFacultyData(Scanner scan)
    {
        //ID
        String next;
        System.out.println("Employee ID: ");
        next = scan.next();
        this.setStaffld(next);
        
        //Department
        System.out.println("Employee Department name: ");
        next = scan.next();
        this.setdName(next);
        
        //Asking if the employee is tenured or not
        System.out.println("Is he or she tenured: ");
        next = scan.next();
        if("yes".equalsIgnoreCase(next)||"y".equalsIgnoreCase(next))
        {
            this.setTenured(true); //If the user presses y or types yes it'll check if its true
        }
        else
        {
            this.setTenured(false); //Does the opposite of what above says
        }
        
        //Faculty Information Screen
        System.out.println("Faculty anaul salary: ");
        this.setaSalary(scan.nextDouble());
        System.out.println("Faculty details: ");
        System.out.println("First Name: ");
        next = scan.next();
        this.setFirstName(next);
        System.out.println("Last Name: ");
        next = scan.next();
        this.setLastName(next);
        System.out.println("Street Adress: ");
        next = scan.next();
        this.setStreetAdress(next);
        System.out.println("Zip Code: ");
        next = scan.next();
        this.setZipCode(next);
        System.out.println("Phone Number: ");
        next = scan.next();
        this.setPhoneNumber(next);
    }
    
}

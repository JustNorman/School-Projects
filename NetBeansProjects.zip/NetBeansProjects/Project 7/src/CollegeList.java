
import java.util.Scanner;

/**
 *
 * @author norma
 */
public class CollegeList 
{
    private CollegeEmployee collegeEmployee[];
    private Faculty faculty[];
    private Student student[];
    
    private int noOfStudents;
    private int noOfEmployees;
    private int noOffaculty;
    
    private final int MAx_NO_OF_STUDENTS = 7;
    private final int MAx_NO_OF_EMPLOYEES = 4;
    private final int MAx_NO_OF_FACULTY = 7;
    
    public CollegeList(CollegeEmployee[] collegeEmployee, Faculty[] faculty, Student[] student)
    {
        this.collegeEmployee = new CollegeEmployee[MAx_NO_OF_EMPLOYEES];
        this.faculty = new Faculty[MAx_NO_OF_FACULTY];
        this.student = new Student [MAx_NO_OF_STUDENTS];
        
        this.collegeEmployee = collegeEmployee;
        this.faculty = faculty;
        this.noOfEmployees = collegeEmployee.length;
        this.noOfStudents = student.length;
        this.noOffaculty = faculty.length;
    }
    
    //Insert Getters
    public int getNoOfStudents() {
        return noOfStudents;
    }

    public int getNoOfEmployees() {
        return noOfEmployees;
    }

    public int getNoOffaculty() {
        return noOffaculty;
    }
    
    //Insert Setters
    public void setNoOfStudents(int noOfStudents) {
        this.noOfStudents = noOfStudents;
    }

    public void setNoOfEmployees(int noOfEmployees) {
        this.noOfEmployees = noOfEmployees;
    }

    public void setNoOffaculty(int noOffaculty) {
        this.noOffaculty = noOffaculty;
    }
    
    public CollegeList()
    {
        this.collegeEmployee = new CollegeEmployee[MAx_NO_OF_EMPLOYEES];
        this.faculty = new Faculty[MAx_NO_OF_FACULTY];
        this.student = new Student[MAx_NO_OF_STUDENTS];
        this.noOfEmployees = 0;
        this.noOfStudents = 0;
        this.noOffaculty = 0;
    }
    
    //Insert Getters#2
    public CollegeEmployee[] getCollegeEmployee() {
        return collegeEmployee;
    }

    public Faculty[] getFaculty() {
        return faculty;
    }

    public Student[] getStudent() {
        return student;
    }
    
    //Insert Setter#2
    public void setCollegeEmployee(CollegeEmployee[] collegeEmployee) {
        this.collegeEmployee = collegeEmployee;
    }

    public void setFaculty(Faculty[] faculty) {
        this.faculty = faculty;
    }

    public void setStudent(Student[] student) {
        this.student = student;
    }
    
    public void addFaculty(Faculty faculty)
    {
        if(noOffaculty<MAx_NO_OF_FACULTY)
        {
            this.faculty[noOffaculty] = faculty;
            noOffaculty++;
        }
        else
        {
            System.out.println("ERROR!! YOU HAVE REACHED THE MAXIUM NO OF FACULTY");
        }
    }
    
    public void addCollegeEmployee(CollegeEmployee collegeEmployee)
    {
        if(noOfEmployees<MAx_NO_OF_EMPLOYEES)
        {
            this.collegeEmployee[noOfEmployees] = collegeEmployee;
            noOfEmployees++;
        }
        else
        {
            System.out.println("ERROR!! YOU HAVE REACHED THE MAXIUM NO OF EMPLOYEES");
        }
    }
    
    public void addStudent(Student student)
    {
        if(noOfStudents < MAx_NO_OF_STUDENTS)
        {
            this.student[noOfStudents] = student;
            noOfStudents++;
        }
        else
        {
            System.out.println("ERROR!! YOU HAVE REACHED THE MAXIUM NO OF STUDENTS");
        }
    }
    
    public static void VIEWGUI() //Who is viewing the information
    {
        System.out.println("Select one of the 4 options below:");
        System.out.println("C: EMPLOYEE");
        System.out.println("F: FACULTY");
        System.out.println("S: STUDENT");
        System.out.println("Q: QUIT");
    }
    
    public static void INSERTGUI()//Who to add
    {
        System.out.println("Select one of the 4 options below:");
        System.out.println("C: EMPLOYEE");
        System.out.println("F: FACULTY");
        System.out.println("S: STUDENT");
        System.out.println("Q: QUIT");
    }
    
    public static void GUI()
    {
        System.out.println("Select one of the 4 options below:");
        System.out.println("I: INSERT"); //INSERT INFORMATION
        System.out.println("D: DELETE"); //DELETE INFORMATION
        System.out.println("V: VIEW"); //VIEW ALL THE INFORMATION ENTERED 
        System.out.println("Q: QUIT");
    }
    
    

    public static void main(String[] args) 
    {
        CollegeList collegeList = new CollegeList();
        Scanner scan = new Scanner(System.in);
        String input;//="";
        do
        {
            GUI();
            input=scan.next();
            if("V".equalsIgnoreCase(input))
            {
                VIEWGUI();
                input=scan.next();
                if("F".equalsIgnoreCase(input))
                {
                    Faculty[] faculty = collegeList.getFaculty();
                    if(faculty.length==0)
                    {
                        System.out.println("NO ONE AVAILABLE\n");
                    }
                    for(int i=0;i<collegeList.getNoOffaculty();i++)
                    {
                        System.out.println("\n");
                        faculty[i].toString();
                        System.out.println("\n\n");
                    }
                }
                if("C".equalsIgnoreCase(input))
                {
                    CollegeEmployee[]emps=collegeList.getCollegeEmployee();
                    if(emps.length==0)
                    {
                        System.out.println("NO ONE AVAILABLE\n");
                    }
                    for(int i=0;i<collegeList.getNoOfEmployees();i++)
                    {
                        System.out.println("\n");
                        emps[i].toString();
                        System.out.println("\n\n");
                    }
                }
                if("S".equalsIgnoreCase(input))
                {
                    Student[] students = collegeList.getStudent();
                    if(students.length==0)
                    {
                        System.out.println("NO ONE AVAILABLE\n");
                    }
                    for(int i=0;i<collegeList.getNoOfStudents();i++)
                    {
                        System.out.println("\n");
                        students[i].toString();
                        System.out.println("\n\n");
                    }
                }
            }
            else
            {
                if(!"I".equalsIgnoreCase(input)&& !"Q".equalsIgnoreCase(input))
                {
                    System.out.println("NOT AVAILABLE\n");
                }
                else
                {
                    INSERTGUI();
                    input = scan.next();
                    if("F".equalsIgnoreCase(input))
                    {
                        collegeList.addStudent(new Student(scan));
                    }
                    else if("C".equalsIgnoreCase(input))
                    {
                        collegeList.addCollegeEmployee(new CollegeEmployee(scan));
                    }
                    else if("S".equalsIgnoreCase(input))
                    {
                        collegeList.addFaculty(new Faculty(scan));
                    }
                    else if(!"Q".equalsIgnoreCase(input))
                    {
                        System.out.println("ERROR ERROR");
                    }
                }
            }
        }
        while(!"Q".equalsIgnoreCase(input));
        //package javaapplication2;
    }
    
}

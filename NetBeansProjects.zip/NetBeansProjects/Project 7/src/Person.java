
import java.util.Scanner;

/**
 *
 * @author norma
 */
public class Person 
{
    protected String fName; //First Name
    protected String lName; //Last Name
    protected String Adress; //Street Adress
    protected String zCode; // Zip Code
    protected String pNumber; //Phone Number
    
    //Insert Setters
    public String getfName() 
    {
        return fName;
    }
    public void setFirstName(String fName)
    {
        this.fName = fName;
    }

    public String getlName() 
    {
        return lName;
    }
    public void setLastName(String lName)
    {
        this.lName = lName;
    }

    public String getAdress() 
    {
        return Adress;
    }
    public void setStreetAdress(String Adress)
    {
        this.Adress = Adress;
    }

    public String getzCode() {
        return zCode;
    }
    public void setZipCode(String zCode)
    {
        this.zCode = zCode;
    }

    public String getpNumber()
    {
        return pNumber;
    }
    public void setPhoneNumber(String pNumber)
    {
        this.pNumber = pNumber;
    }
    
    public Person(){
    }
    
    public Person(Scanner scan)
    {
        setPersonData(scan);
    }
    
    //Insert Getters
    public Person(String fName, String lName, String Adress, String zCode, String pNumber) 
    {
        this.fName = fName;
        this.lName = lName;
        this.Adress = Adress;
        this.zCode = zCode;
        this.pNumber = pNumber;
    }
    
    //Typed up toString method
    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append(this.fName).append(", ");
        sb.append(this.lName).append(", ");
        sb.append(this.Adress).append("-");
        sb.append(this.zCode).append(",");
        sb.append("Ph").append(this.pNumber);
        return sb.toString();
    }
    //Insert toString
    /*@Override
    public String toString() 
    {
        return "Person{" + "fName=" + fName + ", lName=" + lName + ", Adress=" + Adress + ", zCode=" + zCode + ", pNumber=" + pNumber + '}';
    }*/
    
    public void setPersonData(Scanner scan)
    {
       //First Name
       String next;
       System.out.println("First Name: ");
       next = scan.next();
       this.setFirstName(next);
       
       //Last Name
       System.out.println("Last Name: ");
       next = scan.next();
       this.setLastName(next);
       
       //Street Adress
       System.out.println("Street Adress: ");
       next = scan.next();
       this.setStreetAdress(next);
       
       //Zip Code
       System.out.println("Zip Code: ");
       next = scan.next();
       this.setZipCode(next);
       
       //Phone Number
       System.out.println("Phone Number: ");
       next = scan.next();
       this.setPhoneNumber(next);
       
    }
    
    
}


import java.util.Scanner;

/**
 *
 * @author norma
 */
public class CollegeEmployee extends Person 
{
    protected String staffld; //SSN
    protected double aSalary; //Annual Salary
    protected String dName; //Department Name
    
    //Insert Getters
    public String getStaffld() 
    {
        return staffld;
    }

    public double getaSalary() 
    {
        return aSalary;
    }

    public String getdName() 
    {
        return dName;
    }
    
    //Insert Setters
    public void setStaffld(String staffld) 
    {
        this.staffld = staffld;
    }

    public void setaSalary(double aSalary) 
    {
        this.aSalary = aSalary;
    }

    public void setdName(String dName) 
    {
        this.dName = dName;
    }
    
    //Insert Constructor
    public CollegeEmployee(String staffld, double aSalary, String dName) 
    {
        this.staffld = staffld;
        this.aSalary = aSalary;
        this.dName = dName;
    }

    public CollegeEmployee(String staffld, double aSalary, String dName, Scanner scan) 
    {
        super(scan);
        this.staffld = staffld;
        this.aSalary = aSalary;
        this.dName = dName;
    }

    public CollegeEmployee(String staffld, double aSalary, String dName, String fName, String lName, String Adress, String zCode, String pNumber) 
    {
        super(fName, lName, Adress, zCode, pNumber);
        this.staffld = staffld;
        this.aSalary = aSalary;
        this.dName = dName;
    }
    
    //Insert toString
    /*@Override
    public String toString() 
    {
        return "CollegeEmployee{" + "staffld=" + staffld + ", aSalary=" + aSalary + ", dName=" + dName + '}';
    }*/
    //Typed up toString method
    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("Staff ID: ").append(this.staffld);
        sb.append("\n");
        sb.append("Department: ").append(this.dName);
        sb.append("\n");
        sb.append("Anual Salary: ").append(this.aSalary);
        sb.append("\n");
        sb.append("Employee details: ");
        sb.append("\n");
        sb.append(super.fName).append("");
        sb.append(super.lName).append(",");
        sb.append(super.Adress).append("-");
        sb.append(super.zCode).append(",");
        sb.append("Ph").append(super.pNumber);
        return sb.toString();
    }
    
    public CollegeEmployee(){
        
    }
    
    public CollegeEmployee(Scanner scan)
    {
        setCollegeEmployeeData(scan);
    }
    
    public void setCollegeEmployeeData(Scanner scan)
    {
        //ID
        String next;
        System.out.println("ID: ");
        next = scan.next();
        this.setStaffld(next);
        
        //Department
        System.out.println("Department: ");
        next = scan.next();
        this.setdName(next);
        
        //Salury
        System.out.println("Anual Salary: ");
        this.setaSalary(scan.nextDouble());
        
        //Employee Info Prompt
        System.out.println("Employee's Details:");
        
        //Employee First Name
        System.out.println("Employee First Name: ");
        next=scan.next();
        this.setFirstName(next);
        
        //Employee Last Name
        System.out.println("Employee Last Name: ");
        next=scan.next();
        this.setLastName(next);
        
        //Employee Street Adress
        System.out.println("Employee Street Adress: ");
        next=scan.next();
        this.setStreetAdress(next);
        
        //Employee Zip Code
        System.out.println("Employee Zip Code: ");
        next=scan.next();
        this.setZipCode(next);
        
        //Employee Phone Number
        System.out.println("Employee Phone Number: ");
        next=scan.next();
        this.setPhoneNumber(next);
        
    }
    
}

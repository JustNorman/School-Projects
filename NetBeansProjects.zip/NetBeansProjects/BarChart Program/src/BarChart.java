
import java.util.Scanner;

/**
 *
 * @author norma
 */
public class BarChart 
{

    public static void main(String[] args) 
    {
        //Array of Player Names(pName)
        String[] pNames = {"Art","Bob","Cal","Dan","Eli"};
        
        //Array for points
        int[] points = new int[5];
        int i,j;
        
        //User Input 
        Scanner sc = new Scanner(System.in);
        
        //
        for(i=0;i<5;i++)
        {
            System.out.println("\nEnter point scored by "+pNames[i]+"");
            points[i] = sc.nextInt();
        }
        
        //
        System.out.println("\n\nPoints for Game \n");
        
        //bar Chart
        for(i=0;i<5;i++)
        {
            System.out.println("\n"+pNames[i]+"");
            
            //Stars
            for(j=1;j<=points[i];j++)
            {
                System.out.print("*");
            }
        }
        
        System.out.println("\n");
    }
    
}

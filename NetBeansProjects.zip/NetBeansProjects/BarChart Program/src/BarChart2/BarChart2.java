
package BarChart2;

import java.util.Scanner;

/**
 *
 * @author norma
 */
public class BarChart2 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        
        //declare integer variable numberOfPlayers
        int numberOfPlayers;
        
        //declare the  constant AMT_EACH_ASTERISK with value 10
        final int AMT_EACH_ASTERISK = 10;
        
        //prompt user to enter number of players
        System.out.print("Enter number of players: ");
        
        //read numberOfPlayers
        numberOfPlayers=input.nextInt();
        input.nextLine();
        
        //create required parallel arrays to stores names,artPoints,bobPoints,calPoints,danPoints
        //eliPoints and totalPoints
        String names[]=new String[numberOfPlayers];
        int artPoints[]=new int[numberOfPlayers];
        int bobPoints[]=new int[numberOfPlayers];
        int calPoints[]=new int[numberOfPlayers];
        int danPoints[]=new int[numberOfPlayers];
        int eliPoints[]=new int[numberOfPlayers];
        int totalPoints[]=new int[numberOfPlayers];
        
        //for loop iterate numberOfPlayers times
        for(int i=0;i<numberOfPlayers;i++)
        {
            //prompt user to enter name of player i+1
            System.out.print("Enter player "+(i+1)+" name: ");
            //read it into names[i]
            names[i]=input.nextLine();
            System.out.println("Enter points earned for the season");
            //prompt user to enter points earned by Art
            System.out.print(" by Art >> ");
            //read it into artPoints[i]
            artPoints[i] = input.nextInt();
            //prompt user to enter points earned by Bob
            System.out.print(" by Bob >> ");
            //read it into bobPoints[i]
            bobPoints[i] = input.nextInt();
            //prompt user to enter points earned by Cal
            System.out.print(" by Cal >> ");
            //read it into calPoints[i]
            calPoints[i] = input.nextInt();
            //prompt user to enter points earned by Dan
            System.out.print(" by Dan >> ");
            //read it into danPoints[i]
            danPoints[i] = input.nextInt();
            //prompt user to enter points earned by Eli
            System.out.print(" by Eli >> ");
            //read it into eliPoints[i]
            eliPoints[i] = input.nextInt();
            input.nextLine();
            //calculate the total points
            totalPoints[i]=artPoints[i]+bobPoints[i]+calPoints[i]+danPoints[i]+eliPoints[i];
        }

        System.out.println("\nPoints for Season (each asterisk represents " +
                AMT_EACH_ASTERISK + " points)\n");
        //for loop iterate numberOfPlayers times
        for(int i=0;i<numberOfPlayers;i++)
        {
            //call drawChart() ,method by passing information of each player
            drawChart(names[i],totalPoints[i],AMT_EACH_ASTERISK);
        }
    }
    //drawChart() method
    public static void drawChart(String name, int points, int amt_each)
    {//for loop iterate points/amt times
        for(int i=0;i<points/amt_each;i++)
            //print '*"
            System.out.print("* ");
        //display the name in bracket after the bar
        System.out.print("("+name+")");
        //move to next line
        System.out.println();
    }
}

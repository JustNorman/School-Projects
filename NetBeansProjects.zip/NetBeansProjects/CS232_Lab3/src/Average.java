
import java.util.Scanner;

/**
 * For Lab #3, write a program that prompts the user to enter an arbitrary number of  double or floating point literal 
 * decimal values between 1 and 1000 inclusive and determines the smallest and largest values entered by the user as 
 * well as the average of all the numbers entered by the user.  Use double or single precision 
 * floating point numbers (doubles or float data types) for your variables.  
 * Your program is to output the smallest number, the largest number, and the arithmetic average 
 * of all the numbers entered by the user.   You can either ask the user for the number of values 
 * ahead of your input/processing loop or use a sentinel value outside the range of numbers of 1 to 1000 
 * inclusive to signal the end of regular input.  It is up to you.
 *
 * @author norma
 * Due Date: 9/19/2022
 */
public class Average 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in); //in means input
        double input;
        double count =0, Max =0, Min =0, Sum =0; //Variables for count, sum, etc.
        
        System.out.println("Enter 10 numbers between 1 and 1000 (negative to quit):"); //negative so its ends the program, doesn't count towrads the counter
        while((input = in.nextDouble())>0) //Asks for the user's input
        {
            if(count == 0)
            {
                count++;
                Max = input;
                Min = input;
                Sum = Sum+input;
            }
            else
            {
                count++;
                
                if(input>Max)
                {
                    Max = input;
                }
                if(input<Min)
                {
                    Min = input;
                }
                
                Sum = Sum+input;
            }
        }
        
        if(count > 0)
        {
            //Output Screen
            System.out.println("Count: "+ count);
            System.out.println("Max: "+ Max);
            System.out.println("Min: "+ Min);
            System.out.println("Sum: "+Sum);
            System.out.println("Average: "+(Sum/count));
        }
    }
    
}

package example8292022;

/**
 *
 * @author norma
 */
public class Example8292022 
{

    public static void main(String[] args) 
    {
        String f_name = "James";
        String l_name = "Bond";
        int age = 45;
        
        System.out.println("Hello, my name is "+ f_name + " " + l_name + ". I am " + age + " years old.");
        
        String f_name_2 = "Marcus";
        String town = "Bond";
        
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author norma
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hello World");
        System.out.println("I have a twin brother");
        System.out.println("I have 2 little twin brothers");
        System.out.println("Majoring in Computer Science");
        System.out.println("Have some experience with Jave back in High School");
        System.out.println("Have 2 guninea pigs that hate me");
    }
    
}

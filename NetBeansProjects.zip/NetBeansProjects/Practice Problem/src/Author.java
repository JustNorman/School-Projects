/**
 * 2/16/2022
 * @author norma
 */
public class Author 
{
    private String A_Name;
    private String A_Email;
    private String A_Gender;
    private String A_Number;
    
    public static void main(String[] args) 
    {
        
    }
    
}

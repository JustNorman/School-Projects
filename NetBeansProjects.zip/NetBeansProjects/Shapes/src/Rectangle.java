
import java.text.DecimalFormat;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author norma
 */
public class Rectangle 
{
    private double length;
    private double height;
    private double area;
    
    //Multiple Constructors
    public Rectangle()
    {
        length = 1.0;
        height = 1.0;
        
        calculateArea();
    }
    
    public Rectangle(double length, double height)
    {
        this.length= length;
        this.height = height;
    }
    
    public void calculateArea()
    {
        area = length * height;
    }
    
    public void PrintArea()
    {
        DecimalFormat df = new DecimalFormat("##.00");
        System.out.println("Results: " + df.format(area));
    }
}


import java.text.DecimalFormat;

/*

 */

/**
 *
 * @author norma
 */
public class Square 
{
    //
    private double area;
    private double side;
    
    public Square()
    {
        area = 1.0;
        side = 1.0;
        
        calculateArea();
    }
    
    public Square(double side)
    {
        //this.area= area;
        this.side = side;
    }
    
    public void calculateArea()
    {
        area = Math.pow(side, 2);
    }
    
    public void PrintArea()
    {
        DecimalFormat df = new DecimalFormat("##.00");
        System.out.println("Results: " + df.format(area));
    }
}

/**
This program will help us create objects of type square and rectangle.
 */

/**
 *
 * @author norma
 */
public class ShapesTester 
{

    public static void main(String[] args) 
    {
        Square square1 = new Square();
        Square square2 = new Square(150.5689);
        
        Rectangle rectangle1 = new Rectangle();
        Rectangle rectangle2 = new Rectangle(145.4321,567.3425);
        
        square1.PrintArea();
        square2.PrintArea();
        
        rectangle1.PrintArea();
        rectangle2.PrintArea();
    }
    
}

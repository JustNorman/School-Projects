//import java.lang.Exception;
/**
 *
 * @author norma
 */
public class Tic_Tac_Toe_Model 
{
    private static final int DEFAULT_WIDTH = 3;

    public enum Mark
    {
        //Represents the X, O, and the empty squares in the game
        X("X"),
        O("O"),
        EMPTY(" ");
        
        private final String message;
        private Mark(String msg)
        {
            message = msg;
        }
        @Override
        public String toString()
        {
            return message;
        }
    };
    
    public enum Result
    {
        //Shows who won or tied
        X("X Wins!"),
        O("O Wins"),
        TIE("Tie!"),
        NONE(" ");
        
        private final String message;
        private Result(String msg)
        {
            message = msg;
        }
        @Override
        public String toString()
        {
            return message;
        }
    };
    
    private Mark[][]grid; //Grid for the game
    private boolean xTurn; //Player's turn
    private int width; //Size of the grid
    
    //Insert Constructor method
    public Tic_Tac_Toe_Model()
    {
        this(DEFAULT_WIDTH);
    }
    public Tic_Tac_Toe_Model(int width)
    {
        this.width = width;
        xTurn = true;
        grid = new Mark[width][width];
        
        for(int i = 0; i < width; i++)
        {
            for(int j = 0; j < width; j++)
            {
                grid[i][j] = Mark.EMPTY;
            }
        }
    }
    /*public Tic_Tac_Toe_Model(boolean xTurn, int width) {
        this.xTurn = xTurn;
        this.width = width;
        
        grid = new Mark[width][width];
        for(int i = 0; i < width; i++)
        {
            for(int j = 0; j < width; j++)
            {
                grid[i][j] = Mark.EMPTY;
            }
        }
    }
    */
    public boolean makeMark(int row, int col)
    {
        try
        {
            if((!isSquareMarked(row,col)) && (isValidSquare(row,col)))
            {
                if(isXTurn())
                {
                    grid[row][col] = Mark.X;
                    xTurn = false;
                    return true;
                }
                else
                {
                    grid[row][col] = Mark.O;
                    xTurn = true;
                    return true;
                }
            }
        }
        catch (Exception e)
        {
            return false;
        }
        return false;
    }
    
    public boolean isValidSquare(int row, int col)
    {
        return (row < width) && (row >= 0) && (col < width) && (col >= 0);
    }
    
    public boolean isSquareMarked(int row, int col)
    {
        return (grid[row][col] != Mark.EMPTY);
    }
    
    public Mark getMark(int row, int col)
    {
        return grid[row][col];
    }
    
    public Result getResult()
    {
        if (isMarkWin(Mark.X))
        {
            return Result.X;
        }
        else if (isMarkWin(Mark.O))
        {
            return Result.O;
        }
        else if (isTie())
        {
            return Result.TIE;
        }
        else return Result.NONE;
    }
    
    private boolean isMarkWin(Mark mark)
    {
       //Rows
        int j;
        checkRow: for(int i = 0; i < width; i++)
        {
            for(j = 0; j < width; j++)
            {
                if(grid[i][j] != mark)
                {
                    break checkRow;
                }
                if (j == width - 1)
                {
                    return true;
                }
            }
        }
        
        //Columns
        int l;
        checkCol: for(int k = 0; k < width; k++)
        {
            for(l = 0; l < width; l++)
            {
                if(grid[l][k] != mark)
                {
                    break checkCol;
                }
                if (l == width - 1)
                {
                    return true;
                }
            }
        }
        
        //Diagonal
        checkDiag: for (int m = 0; m < width; m++)
        {
            if(grid[m][m] != mark)
            {
                break;
            }
            if(m == width - 1)
            {
                return true;
            }
        }
        return false;
    }
    
    private boolean isTie()
    {
        for(int i = 0; i < width; i++)
        {
            for(int j = 0; j < width; j++)
            {
                if((!isSquareMarked(i,j)) ||(isMarkWin(grid[i][j])))
                {
                    return false;
                }
            }
        }
        return true;
    }
    
    public boolean isGameover()
    {
        return Result.NONE != getResult();
    }
    public boolean isXTurn()
    {
        return xTurn;
    }
    public int getWidth()
    {
        return width;
    }
}

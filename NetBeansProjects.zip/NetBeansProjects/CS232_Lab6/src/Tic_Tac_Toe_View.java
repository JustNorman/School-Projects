import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author norma
 */
public class Tic_Tac_Toe_View extends JPanel implements ActionListener
{
    Tic_Tac_Toe_Model model;
    private final JButton[][] squares;
    private final JPanel squaresPanel;
    private final JLabel resultLabel;
    
    //Constructor Method
    public Tic_Tac_Toe_View(Tic_Tac_Toe_Model model)
    {
        this.model = model;
        int width = model.getWidth();
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        squares = new JButton[width][width];
        squaresPanel = new JPanel(new GridLayout(width,width));
        resultLabel = new JLabel();
        resultLabel.setName("ResultLabel");
        
        for(int i = 0; i < width; i++)
        {
            for(int j = 0; j < width; j++)
            {
                squares[i][i] = new JButton();
                squares[i][i].setName("Square"+i+j);
                squares[i][i].addActionListener(this);
                squares[i][i].setPreferredSize(new Dimension(64,64));
                squaresPanel.add(squares[i][i]);
            }
        }
        add(squaresPanel);
        add(resultLabel);
        
        resultLabel.setText("Welcome to Tic-Tac-Toe!");
    }
    
    //Override Method
    @Override
    public void actionPerformed(ActionEvent event)
    {
        String name = ((JButton)event.getSource()).getName();
        int r = Character.getNumericValue(name.charAt(6));
        int c = Character.getNumericValue(name.charAt(7));
        model.makeMark(r, c);
        updateSquares();
        showResult(" ");
        
        if(model.isGameover())
        {
            showResult(model.getResult().toString());
            for(int i = 0; i < model.getWidth(); i++)
            {
                for(int j = 0; j < model.getWidth(); j++)
                {
                    squares[i][j].setEnabled(false);
                }
            }
        }
    }
    
    public void updateSquares()
    {
        for(int i = 0; i < model.getWidth(); i++)
        {
            for(int j = 0; j < model.getWidth(); j++)
            {
                squares[i][j].setText(model.getMark(i, j).toString());
            }
        }
    }
    public void showResult(String message)
    {
        resultLabel.setText(message);
    }
}

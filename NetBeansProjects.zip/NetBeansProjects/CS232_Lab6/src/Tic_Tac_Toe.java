import javax.swing.JFrame;
/*import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
*/
/**
 *
 * @author norma
 */
public class Tic_Tac_Toe
{
    private static final int DEFAULT_WIDTH = 3;
    
    public static void main(String[] args) 
    {
        //Size
        int width = DEFAULT_WIDTH;
        //
        if(args.length >= 1)
        {
            try
            {
                width = Integer.parseInt(args[0]);
            }
            catch(NumberFormatException e){}
        }
        
        //Objects
        Tic_Tac_Toe_Model model = new Tic_Tac_Toe_Model(width);
        Tic_Tac_Toe_View view = new Tic_Tac_Toe_View(model);
        
        //GUI
        JFrame win = new JFrame("Tic-Tac-Toe");
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.add(view);
        win.pack();
        win.setVisible(true);
    }
    
}

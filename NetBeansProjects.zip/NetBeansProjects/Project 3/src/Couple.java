/**
 *
 * @author norma
 */
public class Couple 
{
    private Person person1;
    private Person person2;
    
    //Insert Constructors
    public Couple(Person p1, Person p2) 
    {
        this.person1 = p1;
        this.person2 = p2;
    }
    
    //Insert Getters
    public Person getFirstPerson() 
    {
        return person1;
    }
    public Person getSecondPerson() 
    {
        return person2;
    }
    
    
    
    
    
}

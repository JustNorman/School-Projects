
import java.time.LocalDate;


/**
 *
 * @author norma
 */
public class Person 
{
    private String firstName;
    private String lastName;
    private LocalDate birthDate;
    
    public Person (String fName, String lName, LocalDate bDate)
    {
        firstName = fName;
        lastName = lName;
        birthDate = bDate;
    }
    
    //Insert Getters
    public String getfirstName() 
    {
        return firstName;
    }
    public String getlastName() 
    {
        return lastName;
    }
    public LocalDate getbirthDate() 
    {
        return birthDate;
    }
    
}

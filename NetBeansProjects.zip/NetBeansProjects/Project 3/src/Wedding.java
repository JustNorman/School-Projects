
import java.util.Date;

/**
 *
 * @author norma
 */
public class Wedding 
{
    private Date wD;//weddingDate
    private Couple cP;//couple
    private String lZ;//location
    
    //Insert Constructors
    public Wedding(Date date, Couple c, String wL) //wL = wedLocation 
    {
        wD = date;
        cP = c;
        lZ = wL;
    }
    
    //Insert Getters
    public Date getwD() {
        return wD;
    }

    public Couple getcP() {
        return cP;
    }

    public String getlZ() {
        return lZ;
    }
    
    
    
}


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author norma
 */
public class TestWedding 
{
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    public static void displayWedding(Wedding w)
    {
        
        Person p1 =w.getcP().getFirstPerson();
        Person p2 =w.getcP().getSecondPerson();
        
        System.out.println(p1.getfirstName()+""+p2.getlastName()+"(born"+p1.getbirthDate().format(DateTimeFormatter.ISO_DATE)+")"+"weds "+p2.getfirstName()+""+p2.getlastName()+"(born "+p2.getbirthDate().format(DateTimeFormatter.ISO_DATE)+")");
        
        System.out.println("ON");
        System.out.println(simpleDateFormat.format(w.getwD()));
        System.out.println("AT");
        System.out.println(w.getlZ());
    }
    
    public static void main(String[]args) throws ParseException
    {
        Person p10 = new Person("First Name", " Last Name", LocalDate.of(2000,10,1));
        Person p11 = new Person("First Name", " Last Name", LocalDate.of(2000,10,1));
        
        Couple c1 = new Couple(p10,p11);
        
        Wedding w1 = new Wedding(simpleDateFormat.parse("2019-05-06"),c1,"CountrySide");
        displayWedding(w1);
        
        Person p20 = new Person("First Name", " Last Name", LocalDate.of(2000,10,1));
        Person p21 = new Person("First Name", " Last Name", LocalDate.of(2000,10,1));
        
        Couple c2 = new Couple(p20,p21);
        
        Wedding w2 = new Wedding(simpleDateFormat.parse("2029-05-06"),c2,"CountrySide");
        displayWedding(w2);
    }
}

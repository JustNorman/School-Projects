
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author norma
 */
public class Inches 
{
    public static final int IN_PER_FOOT =12;
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Inches: ");
        int inches = input.nextInt();
        int feet = inches/IN_PER_FOOT;
        int leftOver = inches%IN_PER_FOOT;
        System.out.println(" "+inches+" inches becomes "+feet+" feet and "+leftOver+" inches");
    }
    
}

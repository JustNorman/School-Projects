/**
 *
 * @author norma
 */
public interface DStack 
{
    /**
     * empty?
     */
    public boolean isEmpty();
    
    /**
     * push
     */
    public void push(double d);
    
    /**
     * pop
     */
    public double pop();
    
    /**
     * peek
     */
    public double peek();
}

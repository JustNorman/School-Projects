/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author norma
 */
public class Test {

    public static String testMethod1(){
        return "Hello, World!";
    }   
    
    public static String testMethod2(){
        return "Hello there, World!";
    }
}

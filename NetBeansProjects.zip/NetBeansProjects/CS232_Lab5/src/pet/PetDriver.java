package pet;

/**
 *
 * @author norma
 */
public class PetDriver 
{
    public static void main(String[] args) 
    {
        //Cat Object
        Cat cat=new Cat("Cat","Jenny","1/14/2022","Stephen",50,'F',"White") {};
        System.out.println("Testing Cat....\n");
        System.out.println(cat.toString());
        System.out.println("\n"+cat.getName()+"'s features:\n");
        cat.climb_trees();
        cat.ignore_owner();
        cat.scratch_post();
        cat.sleep();
        cat.speak();
        
        //Dog Object
        Dog dog=new Dog("Dog","Shadow","1/13/2013","Karen",42.6,'M',"Black") {};
        System.out.println("\nTesting Dog....\n");
        System.out.println(dog.toString());
        System.out.println("\n"+dog.getName()+"'s features:\n");
        dog.play_dead();
        dog.roll_over();
        dog.sit();
        dog.speak();
        dog.whine();
        dog.wag_tail();
        
        //Bird Object
        Bird bird=new Bird("Bird","Rio","1/16/2013","Katlin",15,'F',"Blue") {};
        System.out.println("\nTesting Bird....\n");
        System.out.println(bird.toString());
        System.out.println("\n"+bird.getName()+"'s features:\n");
        bird.fly();
        bird.sing();
        bird.speak();
        
        //Turtle Object
        Turtle turtle=new Turtle("Turtle","Michelangelo","1/13/2013","Master Splinter",60,'M',"Green") {};
        System.out.println("\nTesting Turtle....\n");
        System.out.println(turtle.toString());
        System.out.println("\n"+dog.getName()+"'s features:\n");
        turtle.crawl();
        turtle.hides();
        turtle.speak();
        turtle.speak();
        turtle.swim();
    }
    
}

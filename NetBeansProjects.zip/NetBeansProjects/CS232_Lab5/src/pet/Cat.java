package pet;

/**
 *
 * @author norma
 */
public abstract class Cat extends Pet
{

    public Cat() {
    }

    public Cat(String type, String name, String bDate, String owner, double weight, char sex, String color) {
        super(type, name, bDate, owner, weight, sex, color);
    }
    
    @Override
    public void speak()
    {
        System.out.println("Meow");
    }
    public void scratch_post()
    {
        System.out.println("Sracth noises");
    }
    public void ignore_owner()
    {
        System.out.println("Stares at you blankly");
    }
    public void sleep()
    {
        System.out.println("Zzzzzzz");
    }
    public void climb_trees()
    {
        System.out.println("Climbs Tree");
    }
}

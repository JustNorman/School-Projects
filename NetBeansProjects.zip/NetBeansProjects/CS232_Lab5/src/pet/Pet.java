package pet;

/**
 *
 * @author norma
 */
public abstract class Pet 
{
    protected String type;
    protected String name;
    protected String bDate; //Birthday
    protected String owner;
    protected double weight;
    protected char sex;
    protected String color;
    
    public Pet()
    {
        super();
    }
    
    //Insert Constuctor method
    public Pet(String type, String name, String bDate, String owner, double weight, char sex, String color) {
        this.type = type;
        this.name = name;
        this.bDate = bDate;
        this.owner = owner;
        this.weight = weight;
        this.sex = sex;
        this.color = color;
    }
    
    public abstract void speak();
    public String getTag()
    {
        return "If lost, call"+this.owner;
    }
    
    @Override
    public String toString()
    {
        String str = "Name: "+name+"\n"
                +"Type: "+type+"\n"
                +"Birth Date: "+bDate+"\n"
                +"Owner: "+owner+"\n"
                +"Weight: "+weight+"\n"
                +"Sex: "+((sex=='M')?"Male":"Female")+"\n"
                +"Color: "+color;
        return str;
    }
    
    //Insert Getters and Setters Method
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getbDate() {
        return bDate;
    }

    public void setbDate(String bDate) {
        this.bDate = bDate;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    
}

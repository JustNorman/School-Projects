package pet;

/**
 *
 * @author norma
 */
public abstract class Dog extends Pet
{

    //Insert Method
    public Dog(String type, String name, String bDate, String owner, double weight, char sex, String color) {
        super(type, name, bDate, owner, weight, sex, color);
    }
    
    @Override
    public void speak()
    {
        System.out.println("Meow");
    }
    public void roll_over()
    {
        System.out.println("Rolling");
    }
    public void play_dead()
    {
        System.out.println("Plays dead");
    }
    public void sit()
    {
        System.out.println("sits");
    }
    public void whine()
    {
        System.out.println("Whines");
    }
    public void wag_tail()
    {
        System.out.println("Wags tail");
    }
}

package pet;

/**
 *
 * @author norma
 */
public abstract class Bird extends Pet
{

    public Bird(String type, String name, String bDate, String owner, double weight, char sex, String color) {
        super(type, name, bDate, owner, weight, sex, color);
    }
    
    @Override
    public void speak()
    {
        System.out.println("Chirp");
    }
    public void sing()
    {
        System.out.println("Singing");
    }
    public void fly()
    {
        System.out.println("Flaping Noise");
    }
    public void eating()
    {
        System.out.println("Eats bird seeds");
    }
}

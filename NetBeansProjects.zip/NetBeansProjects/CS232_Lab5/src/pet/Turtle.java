package pet;

/**
 *
 * @author norma
 */
public abstract class Turtle extends Pet 
{

    public Turtle(String type, String name, String bDate, String owner, double weight, char sex, String color) {
        super(type, name, bDate, owner, weight, sex, color);
    }
    @Override
    public void speak()
    {
        System.out.println("Trurle noises");
    }
    public void crawl()
    {
        System.out.println("Crawling");
    }
    public void hides()
    {
        System.out.println("Hides on shell");
    }
    public void swim()
    {
        System.out.println("Swims");
    }
}

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Scanner;

public class Exercises_FileIO 
{
    public static void main(String[] args) throws IOException
    {
      
      //open input file and echo input file text contents to the screen
      //Scanner input = new Scanner(Paths.get("lab2_input.txt"), "UTF-8");
      /*Scanner input = new Scanner(Paths.get("input.txt")); //, "UTF-8"); 
      
      System.out.println("Please enter the number of items: ");
      int num_items = input.nextInt(); 
      int current_num;
      int counter = 0;
      
      while (counter <= num_items)
      {
          current_num = input.nextInt();
          System.out.print(current_num + " ");
          counter++;
      }
      
      /*while (input.hasNext()) 
      {
            System.out.println(input.nextInt());
      }*/
      
       // Scanner input = new Scanner(System.in);
        
       //Write a Java program to get a number from the user and print whether it is positive or negative.
            //Test Data Input number: 35 
            //Expected Output : Number is positive
        
        
        /*Scanner in = new Scanner(Paths.get("input.txt"), "UTF-8");
        
        System.out.print("Please enter an integer:  ");
        //int data = input.nextInt();
        int data;
        while (in.hasNext())
        {
            data = in.nextInt();
            
            if (data > 0)
            {
                System.out.println("The Number is a positive number.");
            }
            else if (data < 0)
            {
                System.out.println("The Number is a negative number.");
            }
            else
            {
                System.out.println("The Number is zero.");
            }
        }
        
        */
        // ask user for coefficients to the quadratic formula and calculate its roots 
        
        /*System.out.println("Please enter the coefficients a, b, and c for the quadratic formula");
        
        System.out.print("Input a: ");
        double a = input.nextDouble();
        System.out.print("Input b: ");
        double b = input.nextDouble();
        System.out.print("Input c: ");
        double c = input.nextDouble();

       double result = b * b - 4.0 * a * c;

       if (result > 0.0 && a != 0) 
       {
            double r1 = (-b + Math.pow(result, 1.0/2.0)) / (2.0 * a);
            double r2 = (-b - Math.pow(result, 1.0/2.0)) / (2.0 * a);
            System.out.println("The roots are " + r1 + " and " + r2);
       }
       else if (result == 0.0 && a != 0) 
       {
            double r1 = -b / (2.0 * a);
            System.out.println("The root is " + r1);
       }
       else 
       {
            System.out.println("The equation has no real roots.");
       }*/
       
       
       //Choose the largest number of three user entered integers.
        System.out.print("Input the 1st number: ");
        int num1 = input.nextInt();

        System.out.print("Input the 2nd number: ");
        int num2 = input.nextInt();

        System.out.print("Input the 3rd number: ");
        int num3 = input.nextInt();


        if ((num1 > num2) && (num1 > num3))
        {
          System.out.println("The greatest: " + num1);
        }
        else if ((num2 > num1) && (num2 > num3))
        {
          System.out.println("The greatest: " + num2);
        }
        else if ((num3 > num1) && (num3 > num2))
        {
          System.out.println("The greatest: " + num3);
        }
        else
        {
            System.out.println("The largest number of these three numbers is equivalent to at least one of the other two numbers.");
        }
        
        /*
        //Ask the user for a year and output whether or not it is a leap year or not
        System.out.print("Please enter a year and I will tell you whether or not it is a leap year:  ");
        int year = input.nextInt();
        boolean leap_year = false;
        if (year % 100 == 0 || year % 4 == 0)
        {
            leap_year = true;
        }
        
        if (leap_year)
        {
            System.out.println(year + " is a leap year!");
        }
        else
        {
            System.out.println(year + " is NOT a leap year!");
        }
        */
        /*
        //Ask the user for 5 numbers from keyboard, calculate and output their sum and average
        System.out.println("Please enter 5 numbers (seperate each number with a space)");
        double one = input.nextDouble();
        double two = input.nextDouble();
        double three = input.nextDouble();
        double four = input.nextDouble();
        double five = input.nextDouble();
        
        double sum = one + two + three + four + five;
        double average = sum / 5.0;
        
        System.out.println("The Sum is:  " + sum);
        System.out.println("The Average is:  " + average);*/
        
    } //end main
    
}//end main class

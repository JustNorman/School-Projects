import java.util.Scanner;

public class ESSA 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in); //Allows users to input via keyboard
        
        //
        String response;
        
        //Keyboard Chat
        System.out.println("Hello, how are you?"); //Greatings
        response = in.next();
        System.out.println(response);
    }
    
}

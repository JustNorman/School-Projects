
import java.util.Scanner;


/*
 * Author: Martell N.
 * Date: 3/4/22
 */
public class BarChart 
{
    public static void main(String[] args) 
    {
        //Array(s)for Player Names
        String[] playerNames = {"Art","Bob","Cal", "Dan", "Eli"};
        
        //Array)s) for points
        int[] points = new int[5];
        int i, j;
        
        //Scanner object
        Scanner sc = new Scanner(System.in);
        
        //
        for(i=0; i<5; i++)
        {
            
        }
    }
    
}

/**
 *
 * @author norma
 */

import java.text.DecimalFormat;

public class HeatIndexCalculator 
{
    //Heat Index Calculation constants
    private static final double c1 = 42.379;
    //
    //
    //private static final double c7 = 1.22874 * Math.pow(10.0, -3);
    private static final double c7 = 0.00122874;
    //private static final double c7 = 1.22874e-3;
    
    DecimalFormat df = new DecimalFormat("###.###");
    
    //System.out.println("");
    
}

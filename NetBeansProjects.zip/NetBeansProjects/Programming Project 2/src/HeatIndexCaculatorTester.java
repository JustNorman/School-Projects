/**
 *
 * @author norma
 */


import java.text.DecimalFormat;

public class HeatIndexCaculatorTester 
{
   static double my_cons = 0.00122874;
   public static void main(String[] args)
   {
       DecimalFormat my_df = new DecimalFormat("000.###");
       System.out.println("The formatted number is: " + my_df.format(my_cons));
   }
}

/*
Problem:
Write a program that takes as input any change expressed in cents.
It should then compute the number of hlaf-dollars, quartes, dimes,
nickels, and pennies to be returned, returning as many half-dollars
as possible, then quarters, dimes, nickels, and pennies, in that order.
For example, 483 cents should be returned as 9 half-dollars, 1 quarter,
1 nickel, and 3 pennies.
*/

/**
 *
 * @author norma
 */
import java.util.Scanner;
public class Cents 
{
    public static void main(String[] args) 
    {
        //System will read out message to user
        System.out.println("Welcome to the Coin Calculator!!");
        
        //Step 1: Define Coin value
        final int Half_Dollar = 50;
        final int Quarter = 25;
        final int Dime = 10;
        final int Nickel = 5;
        
        //Step 2: Variables
        int total_cents;
        int modified_cents;
        int half_dollars;
        int quarters;
        int dimes;
        int nickels;
        int pennies;
        
        //Step 3: User Input
        System.out.println("Please enter your values when prompted.");
        Scanner inputDevice = new Scanner(System.in);
        total_cents = inputDevice.nextInt();
        
        modified_cents = total_cents;
        
        //Step 4:Get the largest amount of half dollars and remaing cents
        half_dollars = modified_cents / Half_Dollar;
        modified_cents = modified_cents % Half_Dollar;
        //Quartes
        quarters = modified_cents / Quarter;
        modified_cents = modified_cents % Quarter;
        //Dimes
        dimes = modified_cents / Dime;
        modified_cents = modified_cents % Dime;
        //Nickels
        nickels = modified_cents / Nickel;
        modified_cents = modified_cents % Nickel;
        //Pennies
        pennies = modified_cents;
        
        //Step 6: Output
        System.out.println(+total_cents+ " is equal to "+half_dollars+ " half dollar(s) "+quarters+ " quarter(s) "+dimes+ " dime(s) "+nickels+ " nickel(s), "+pennies+ " and lastly pennies.");
    }
    
}


import java.util.Scanner;


public class Exercises_SelectionIteration
{
  public static void main(String[] args)
  {
      Scanner input = new Scanner(System.in);
      
      
      double miles;
      double destination;
      int counter = 0;
  
      /*ask the user for how many miles are between them and their destination
        create a counter initialized to 0 miles
        and add each mile to that counter displaying a message keep driving until you have reached your destination
      */
      System.out.println("How many miles are between you and your destination?");
      miles = input.nextInt();
      destination = input.nextInt();
      while (counter <= miles)
      {
          System.out.println(destination +"Keep driving until you have reached your destination");
          counter++;
      }
      System.out.println("You have reached you destination");

      
      /*  ask the user to enter the balance of their bank accounts,
          If they have savings equal to $1000.00 or higher then tell them that they can go on vacation
          If they have savings less than $1000.00, tell them to stay home */
      
      //Scanner input = new Scanner (System.in);
      
      double savings;
      
      System.out.println("Enter your current balance here: ");
      savings = input.nextDouble();
      
      if(savings <= 1000)
      {
          System.out.println("Stay home");
      }
      else
      {
          System.out.println("You can go on vacation");
      }

     /*  Ask the user to enter a numeric score and using both if-then-elses to determine their letter grade and then
	and then use that letter grade character as the switch control variable for a switch statement that outputs
        an appropriate message for the letter grade they earned based on that letter grade character variable.
     */

     /*  Ask the user for a number and then display all numbers from 1 to that number 
       and their cube out to the console window  */
     

         


     /*  Ask the user for 10 numbers and output the highest and lowest number entered to the screen.  */
     int highest=0;
     int lowest=0; 
     int num=0;
     
     for (int i=0; i<10; i++)
     {
         System.out.print("Enter 10 numbers: ");
         num = input.nextInt();
     }
     
     if (num > highest)
     {
         highest = num;
     }
     else if(num < lowest) 
     {
         lowest = num;
     }
     
     System.out.println("Highest number is: " + highest);
     System.out.println("Lowest number is: " + lowest);
     //Scanner input = new Scanner(System.in);
     //System.out.println("");

      
  
  }
}


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author norma
 */
public class Lab2 
{
    public static void main(String[] args) throws FileNotFoundException 
    {
        //Reads "lab2_input.txt" file
        Scanner sc = new Scanner(new File("lab2_input-1.txt"));
        
        //Declaring tthe variables
        int i;
        int count=0;
        int []a = new int[100];
        int []b = new int [8];
        
        //Sets to 0
        for(i = 0; i < b.length; i++)
        {
            b[i] = 0;
        }
        
        //Reads the file
        while(sc.hasNext())
        {
            a[count] = sc.nextInt();
            count++;
        }
        
        //Checks to each count
        for(i = 1; i < count; i++)
        {
            if(a[i] >= 0 && a[i] < 25)//Range is 25
            {
                b[0]++;
            }
            else if(a[i] >= 25 && a[i] < 50)//Range is 50
            {
                b[1]++;
            }
            else if(a[i] >= 50 && a[i] < 75)//Range is 75
            {
                b[2]++;
            }
            else if(a[i] >= 75&& a[i] < 100)//Range is 100
            {
                b[3]++;
            }
            else if(a[i] >= 100 && a[i] < 125)//Range is 125
            {
                b[4]++;
            }
            else if(a[i] >= 125 && a[i] < 150)//Range is 150
            {
                b[5]++;
            }
            else if(a[i] >= 150 && a[i] < 175)//Range is 175
            {
                b[6]++;
            }
            else if(a[i] >= 175 && a[i] < 200)//Range is 200
            {
                b[7]++;
            }
        }
        
        //Output
        System.out.println("[0 - 24]: "+b[0]);
        System.out.println("[25 - 49]: "+b[1]);
        System.out.println("[50 - 74]: "+b[2]);
        System.out.println("[75 - 99]: "+b[3]);
        System.out.println("[100 - 124]: "+b[4]);
        System.out.println("[125 - 149]: "+b[5]);
        System.out.println("[150 - 174]: "+b[6]);
        System.out.println("[175 - 200]: "+b[7]);
        
    }
    
}

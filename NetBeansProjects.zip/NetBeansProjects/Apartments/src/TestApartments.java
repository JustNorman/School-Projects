
import java.util.Scanner;

/**
 *
 * @author norma
 */
public class TestApartments 
{

    public static void main(String[] args) 
    {
        //Apartment Arrays
        Scanner input = new Scanner(System.in);
        Apartment apts[] = new Apartment[5];
        apts[0] = new Apartment(64,255,119,666);
        apts[1] = new Apartment(681,587,270,400);
        apts[2] = new Apartment(205,349,257,516);
        apts[3] = new Apartment(384,483,1003,703);
        apts[4] = new Apartment(298,573,1094,916);
        
        int bdrms;
        int baths;
        double rent;
        int count = 0;
        
        //Asks for user input(s)
        System.out.println("Enter minimum number of bedrooms needed: ");
        bdrms = input.nextInt();
        System.out.println("Enter minimum number of bathrooms needed: ");
        baths = input.nextInt();
        System.out.println("Whats the maximum rent you're willing to pay: ");
        rent = input.nextInt();
        
        //Output
        //System.out.println("\nThe Apartments that meet your citeria:\nBedrooms: "+bdrms+ "\nBathrooms: "+baths+ "\nRent per month: $"+rent+);
    }
    
}

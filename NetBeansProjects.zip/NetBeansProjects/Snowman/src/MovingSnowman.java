import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MovingSnowman extends JFrame implements ActionListener
{
    private int x=100,y=100;
    
    private JButton up=new JButton("Up!");
    private JButton down=new JButton("Down!");
    private JButton left=new JButton("Left!");
    private JButton right=new JButton("Right!");
    private JPanel p1 = new JPanel(new FlowLayout());
    
    public MovingSnowman()
    {

        super("Moving Snowman");
        
        setLayout(new BorderLayout());
        
        //Add ActionLisneners to each Button
        up.addActionListener(this);
        down.addActionListener(this);
        left.addActionListener(this);
        right.addActionListener(this);
             
        //Add Buttons to frame
        p1.add(up);
        p1.add(down);
        p1.add(left);
        p1.add(right);
        add(p1, BorderLayout.NORTH);
        add(new SnowmanPanel(), BorderLayout.CENTER);
        
        // configure the panel
        
        setSize(500, 500);
 
        setVisible(true);
    }

    class SnowmanPanel extends JPanel
    {
        @Override
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);

            setBackground(Color.GREEN);
            g.setColor(Color.white);
            g.fillOval(x-20, y-60, 40, 40);  //head
            g.fillOval(x-35, y-25, 70, 50);  //upper body
            g.fillOval(x-50, y+20, 100, 60);  //lower body

            g.setColor(Color.black);
            g.fillOval(x-10, y-50, 5, 5);  //left eye
            g.fillOval(x+5, y-50, 5, 5);  //right eye
            g.drawArc(x-10, y-40, 20, 10, 190, 160);  //smile
            g.drawLine(x-25, y, x-50, y-20);  //left arm
            g.drawLine(x+25, y, x+55, y); //right arm

            g.drawLine(x-20, y-55, x+20, y-55);  //brim of hat
            g.fillRect(x-15, y-80, 30, 25);  //hat

        }

    }
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==up)
        {
            y=y-10;
        }
        if(e.getSource()==down)
        {
            y=y+10;
        }
        if(e.getSource()==left)
        {
            x=x-10;
        }
        if(e.getSource()==right)
        {
            x=x+10;
        }
        repaint();
    }

    public static void main(String[] args)
    {
        JFrame frame = new MovingSnowman();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setVisible(true);
    }
}

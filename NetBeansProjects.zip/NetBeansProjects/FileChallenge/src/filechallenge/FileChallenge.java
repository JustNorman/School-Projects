
package filechallenge;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author norma
 */
public class FileChallenge 
{

    public static void main(String[] args) 
    {
        //Creates file(s)
        File menuIs = new File("menuNoPrices.txt"); //menuI = menuItems
        File menuPs = new File("menuWithPrices.txt"); //menuP = menuPrices
        String menuI;
        double p; //p = price
        
        try
        {
            Scanner input = new Scanner(menuIs);
            PrintWriter output = new PrintWriter(menuPs);
            Scanner in = new Scanner(System.in);
            while(input.hasNextLine())
            {
                //User Input
                menuI = input.nextLine();
                System.out.println("Price: "+ menuI);
                p = in.nextDouble();
                in.nextLine();
                output.print(menuI);
                output.print("\t");
                output.print(p);
            }
            output.close();
        }
        catch (Exception e)
        {
            //If wrong info inputed, outputs "ERROR"
            System.out.println("ERROR"+ e.toString());
        }
    }
    
}

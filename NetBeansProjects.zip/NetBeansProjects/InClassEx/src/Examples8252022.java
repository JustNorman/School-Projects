/*
 * @author Martell Norman
 * CS 232 - 002
 * In Class Examples
 * Due Date: Sept. 2, 2022
 */



public class Examples8252022
{

    public static void main(String[] args) 
    {
        
  
        
        //1.  Declare a String variable firstname and assign James to it
        String f_name = "James";
        //2.  Declare a String variable lastname and assign Bond to it.
        String l_name = "Bond";
        //3.  Declare an int variable age and assign 45 to it.
        int age = 45;
        
        /*
          Concantenate the strings together into a message 
          that reads "Hello, my name is firstname lastname and I
          am 45 years old."
        */
        System.out.println("Hello, my name is "+ f_name + " " + l_name + " and I am " + age + " years old.");
        
        
        
        //1.  Create two or three String variables and assign values to them
        String fname = "Marcus";
        String home = "Happyville";
        String home_2 = "Yak butter";
        //2.  Create two or three int variables and assign values to them
        int age_2 = 150;
        int sib_1 = 13;
        int sib_2 = 8;
        //3.  Write a short story such as or similiar to the following:
        
        /*"Hello, my name is Marcus and I am over 150 years old.  
        I grew up in a small village called Happyville
        and I was able to live this long on Yak butter alone!  
        I have 13 brothers and 8 sisters who live in the 
        village with me."
        */
        System.out.println("\nHello, my name is "+ fname + " and I am over "+ age_2 +
                " years old. \nI grew up in a small village called  "+ home + "\nand I was able to live this long on "
                + home_2 + " alone! \nI have "+ sib_1 + " brothers and " + sib_2 + " sisters who live in the village with me.\n");
        
        

	/*  Try to assign values to each of the primitive data types */
        

	/*Try to find out what is displayed if you go beyond the maximum value of a primitive data type's fixed numerical boundaries */
        

        
        /*Decimal values are doubles by default, try forcing the Java Interpreter to treat a decimal literal value as a float instead. */
        
   

        //Experiment with some arithmetic of the various primitive data types
        


	//Create a Random Number between 5 and 5000 
        System.out.println(Math.floor(Math.random()*5000)+5);

    }
    
}


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author norma
 */
public class Rectangle 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int l,b,area;
        System.out.println("Value of your sides: ");
        //User Input
        Scanner r=new Scanner(System.in);
        l=r.nextInt();
        b=r.nextInt();
        area=l*b;
        System.out.println("Area of rectangle "+area);
        
    }
    
}

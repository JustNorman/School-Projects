
package phonenumbers;

import java.util.Scanner;

/**
 *
 * @author norma
 */
public class PhoneNumbers 
{
    String names[];
    String numbers[];
    int count;
    public PhoneNumbers()
    {
        this.names=new String[6];
        this.numbers=new String[6];
        
        //Arrays for names and numbers
        names[0]="Aashya";
        numbers[0]="+1 202-918-2132";
        names[1]="Ryan";
        numbers[1]="+1 303-865-0624";
        names[2]="Kennedy";
        numbers[2]="+1 518-467-9788";
        names[3]="Sawyer";
        numbers[3]="+1 582-600-2499";
        names[4]="Gary";
        numbers[4]="+1 309-481-9366";
        names[5]="Tongyu";
        numbers[5]="+1 582-333-1272";
        this.count=6;
    }
    
    public String getNumber(String s)
    {
        for(int i=0;i<this.count;i++)
            if(s.equals(this.names[i]))
                return this.numbers[i];
        return"";
    }
    
    public void addNumber(String name)
    {
        //Ask the user for their input
        System.out.print("Enter a number: ");
        Scanner sc=new Scanner(System.in);
        String num=sc.next();
        
        //Looks to see if this number and user exist
        this.names[this.count]=name;
        this.names[this.count]=num;
        this.count++;
        if(count==6)
            System.exit(0);
    }
    
    public boolean Exist(String name)
    {
        for(int i=0;i<this.count;i++)
        {
            //Checking if this is right
            if(name.equals(this.names[i]))
            return true;
        }
        
        return false;
    }
    
    public String toString()
    {
        String s="";
        for(int i=0;i<this.count;i++)
            s+=this.names[i]+""+this.numbers[i]+"\n";
        return s;
    }
    
    public static void main(String[] args) 
    {
        //phoneBook holds all the phone numbers mentioned above
        PhoneNumbers phoneBook=new PhoneNumbers();
        System.out.println(""+phoneBook);
        Scanner sc=new Scanner(System.in);
        String name;
        while(true)
        {
            System.out.println("Enter name: ");
            name=sc.nextLine();
            System.out.println(""+name);
            if(phoneBook.Exist(name)) {
                phoneBook.addNumber(name);
            } else
                System.out.println(name+" : "+phoneBook.getNumber(name));
        }
        
    }
    
}

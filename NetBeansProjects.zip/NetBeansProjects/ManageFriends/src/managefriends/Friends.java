/*
* @author norma
 * January 31, 2021
 */
package managefriends;

public class Friends 
{
    //Define Variables
    private String firstName;
    private String lastName;
    
    public static int totalFriends = 0;
    
    //Constructor
    public Friends(String fName, String lName)
    {
        firstName = fName;
        lastName = lName;
        
        totalFriends++;
        
        //System Output (Optional)
        
        
    }
    
    public static void printInformation()
    {
        System.out.println("This is template that stores info about Friends.");
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
     public String getLastName()
    {
        return lastName;
    }
     
     
}

/*
Create a java project (ManageFriends) that uses two source files: ManageFriends.java and Friends.java.

Friends.java has two private string variables: firstName and lastName and following methods: 

Friends(String first, String last) //constructor 

printInformation() // A static method that explains what Friends class does

Include your test code in ManageFriends. java class - create three Friend instances

Also, implement your program in such a way so that each instance can remember 
how many instances of Friends class you have already created (Hint: your have to use a static variable).
*/

/*
 * @author norma
 * January 31, 2021
 */

package managefriends;

public class ManageFriends {

    public static void main(String[] args) 
    {
        //instantiate three objects of class "Friends"
        Friends friend1 = new Friends("Jamie","Pickle");
        Friends friend2 = new Friends("Melissa", "Wilson");
        Friends friend3 = new Friends("Chris", "Wood");
        
        //Output
        System.out.println("My friends are: ");
        System.out.println("\t" + friend1.getFirstName() + " " + friend1.getLastName());
        System.out.println("\t" + friend2.getFirstName() + " " + friend2.getLastName());
        System.out.println("\t" + friend3.getFirstName() + " " + friend3.getLastName());
        
        //Print out the total number of friends from the static variable class Friends
        //totalFriends
        System.out.println("Total number of friends: " + Friends.totalFriends);
        
        //call the static method, printInformation(), from the class Friends, which prints out
        Friends.printInformation();
        
    }
    
}

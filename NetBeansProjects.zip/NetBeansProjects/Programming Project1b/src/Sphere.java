
import java.util.Scanner;
/*
@author norma
January 30, 2021
*/
public class Sphere 
{
    public static void main(String[] args) 
    {
        //Scanner for User Input(s)
        Scanner scnr = new Scanner(System.in);
        
        //Message Read out
        System.out.println("Enter Radius: ");
        double radius = scnr.nextDouble(); //Lets us input any number we desire
        
        //Math 
        double circleCircumference = 2*Math.PI*radius;
        double circleArea = Math.PI*(Math.pow(radius,2));
        double sphereArea = 4*Math.PI*(Math.pow(radius,2));
        double sphereVolume = (4/3)*Math.PI*(Math.pow(radius,3));
        
        //System now reads out information given
        System.out.println("Circle Circumference = "+circleCircumference);
        System.out.println("Circle Area = "+circleArea);
        System.out.println("Sphere Area = "+sphereArea);
        System.out.println("Sphere Volume = "+sphereVolume);
    }
    
}

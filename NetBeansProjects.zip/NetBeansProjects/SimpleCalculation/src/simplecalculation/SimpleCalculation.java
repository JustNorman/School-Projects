
package simplecalculation;

import java.util.Scanner;

public class SimpleCalculation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Here is to calculate my surface area
        double w, l, h;
        double numWin, winWidth, winHeight;
        double numDoors, doorWidth, doorHeight;
        double surfaceArea;
        
        //Using to fill in my values
        System.out.println("Please enter the width, length, and height of"
                + "the house to be painted.");
        //This will be able to read the user's data
        Scanner in = new Scanner(System.in);
        w = in.nextDouble();
        l = in.nextDouble();
        h = in.nextDouble();
        
        //Asking the user input data
        System.out.println("Please enter the number of windows, width and height");
        numWin = in.nextDouble();
        winWidth = in.nextDouble();
        winHeight = in.nextDouble();
        System.out.println("Please enter the number of doors, width and height");
        numDoors = in.nextDouble();
        doorWidth = in.nextDouble();
        doorHeight = in.nextDouble();
        
        //Calulation of the Surface Area
        surfaceArea = (w * h * 2 + 1 * h * 2) - (numWin * winWidth * winHeight +
                numDoors * doorWidth * doorHeight);
                System.out.println("The total paintable surface area is: " + surfaceArea);
        
    }
    
}

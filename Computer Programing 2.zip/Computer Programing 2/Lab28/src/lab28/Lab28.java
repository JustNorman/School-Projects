/*
Problem Defintion: 
 Write a program that gives all prime numbers between 1 and 100.
Author: Montell N.
Date: 4/21/21
 */
package lab28;

public class Lab28 {

    public static void main(String[] args) {
        for(int i = 2; i <= 100; i++){ // i = 2
            int count = 0; //count = 0
            for(int num = i; num >= 2; num--){ //num i = 2; next loop = 2-1 = 1
                if(i % num == 0){
                    count++; //count = 1
                }
            }
            if(count == 1){
                System.out.println(i);
            }
        }
    }
    
}

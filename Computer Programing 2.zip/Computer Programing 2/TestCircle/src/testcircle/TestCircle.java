/*
Problem Defintion
b) Create a class named TestCircle whose main() method declares several Circle objects.
Using the setRadius() method, assign one Circle a small radius value, and assign another a larger radius value.
Do not assign a value to the radius of the third circle; instead, retain the value assigned at construction.
Display all the values for all the Circle objects. Save the application as TestCircle.java.
Author: Montell N.
Date: 1/29/21
 */
package testcircle;

import java.text.DecimalFormat;//This class is used to format differnt number types that I specify for


public class TestCircle {
    
    private static DecimalFormat df = new DecimalFormat("#.##");//This private static will be only access to the getArea code to shorten the decimals


    public static void main(String[] args) {
        //Create circle objects
        Circle circle1 = new Circle();
        Circle circle2 = new Circle();
        Circle circle3 = new Circle();
        
        circle1.setRadius(6.9);
        circle2.setRadius(425.8);
        
        System.out.println("\nCircle 1: ");//From the bluprint I made in Circle.java, the program is now calling back
        System.out.println("The diameter is: " + circle1.getDiameter());//the getDiameter, Area, and Radius is recognize
        System.out.println("The area is: " + df.format(circle1.getArea()));//and is calculated
        System.out.println("The radius is: " + circle1.getRadius());
        
        System.out.println("\nCircle 2: ");
        System.out.println("The diameter is: " + circle2.getDiameter());
        System.out.println("The area is: " + df.format(circle2.getArea()));
        System.out.println("The radius is: " + circle2.getRadius());
        
        
        System.out.println("\nCircle 3: ");
        System.out.println("The diameter is: " + circle3.getDiameter());
        System.out.println("The area is: " + df.format(circle3.getArea()));
        System.out.println("The radius is: " + circle3.getRadius());
    }
    
}

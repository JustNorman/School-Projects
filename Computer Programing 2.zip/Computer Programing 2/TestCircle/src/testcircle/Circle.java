/*
 a) Create a class named Circle with fields named radius, diameter, and area. 
Include a constructor that sets the radius to 1 and calculates the other two values.
Also include methods named setRadius() and getRadius().
The setRadius() method not only sets the radius, but it also calculates the other two values.
(The diameter of a circle is twice the radius, and the area of a circle is pi multiplied by the square of the radius.
Use the Math class PI constant for this calculation.) Save the class as Circle.java.
 */
package testcircle;

public class Circle {
    //List all the attributes
    private double radius;
    private double diameter;
    private double area;
    
    //Constructor
    public Circle(){
        radius = 1;
        
        computeDiameter();//Calculate diameter
        
        computeArea();//Calculate area
    }
    public void setRadius(double radiusValue){
        radius = radiusValue;
        
        computeDiameter();//Calculate diameter
        
        computeArea();//Calculate area
    }
    public double getRadius(){
        return radius;
    }
    
    public double getDiameter(){
        return diameter;
    }
    
    public double getArea(){
        return area;
    }
    
    private void computeDiameter(){
        diameter = 2 * radius;
    }
    
    private void computeArea(){
        area = Math.PI * radius * radius;
    }
}

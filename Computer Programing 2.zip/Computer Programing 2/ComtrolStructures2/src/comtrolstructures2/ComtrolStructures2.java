/*
Problem Defintion
Making Decisions and Looping 
Author: Montell N.
Date: 2/24/21
 */
package comtrolstructures2;

public class ComtrolStructures2 {

    public static void main(String[] args) {
        int i = 0;
        //While loop
        while (i <= 10){
            System.err.println("Value of i: " + i);
            //i++; //i = i + 1
            //i = i + 2;
            i += 2;
        }
        
        for(i = 0; 1 <= 10; i++){
            System.out.println("Value of i: " + i);
        }
        /*
        For loop
        for(statemts 1; statement 2; statement 3){
            
        }*/
        //Enhanced for loop
        //Array
        String myArray[] = {"John", "David", "James", "Andy"};
        for(String s:myArray){
            System.out.println(s);
        }


        //do - while
        do{
            System.err.println("Value of i: " + i);
            //i++; //i = i + 1
            //i = i + 2;
            i += 2;
        }while(i <= 10);
        
        //break, continue
        for(i = 0; i <= 10; i++){
            if(i == 5){
                break;
            }
            System.out.println("Value of i: " + i);
        }
        
        for(i = 0; i <= 10; i++){
            if(i%2 != 0){
                continue;
            }
            System.out.println(i);
        }
        
        
    }
    
}

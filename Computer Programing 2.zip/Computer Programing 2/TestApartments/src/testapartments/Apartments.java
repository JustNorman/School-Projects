/*
Author: Martell N.
Date: 3/4/22
 */
package testapartments;


public class Apartments 
{
    //Class varibles for Apartments
    private int apmtNumber;
    private int bedrooms;
    private int bathrooms;
    private double rentAmount;
    
    public Apartments(int apmtNumber, int bedrooms, int bathrooms, double rentAmount)
    {
        this.apmtNumber = apmtNumber;//From line 24-27 using the this.varible method will tell the constructor to not get confuse for the
        this.bedrooms = bedrooms;//similar names for being seperate 
        this.bathrooms = bathrooms;
        this.rentAmount = rentAmount;
    }
    

    public int getApmtNumber()
    {//The getter methods will return the value of the number for each method for
        return apmtNumber;//Line 31-42
    }
    public int getBedrooms()
    {
        return bedrooms;
    }
    public int getBathrooms()
    {
        return bathrooms;
    }
    public double getRentAmount()
    {
        return rentAmount;
    }
    
}

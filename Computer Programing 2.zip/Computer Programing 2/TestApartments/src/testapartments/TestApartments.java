/*
Author: Martell N.
Date: 3/4/22
 */
package testapartments;
import java.util.Scanner;

public class TestApartments 
{

    public static void main(String[] args) 
    {
        //Creating apartments objects
        Apartments apartment1 = new Apartments(80, 5, 3, 499.00);
        Scanner input = new Scanner(System.in);
        System.out.println("How many bedrooms do you want?");
        int bedrooms1 = input.nextInt();
        System.out.println("How many bathrooms do you want?");
        int bathrooms1 = input.nextInt();
        System.out.println("And the maximum rent you're looking for?");
        double rent1 = input.nextDouble();
        
        Apartments apartment2 = new Apartments(75,2, 1, 199.00);//For each apmt varible the user must put in different answers
        Scanner input2 = new Scanner(System.in);
        System.out.println("How many bedrooms do you want?");
        int bedrooms2 = input2.nextInt();
        System.out.println("How many bathrooms do you want?");
        int bathrooms2 = input2.nextInt();
        System.out.println("And the maximum rent you're looking for?");
        double rent2 = input2.nextDouble();
        
        Apartments apartment3 = new Apartments(42,1, 1, 100.00);
        Scanner input3 = new Scanner(System.in);
        System.out.println("How many bedrooms do you want?");
        int bedrooms3 = input3.nextInt();
        System.out.println("How many bathrooms do you want?");
        int bathrooms3 = input3.nextInt();
        System.out.println("And the maximum rent you're looking for?");
        double rent3 = input3.nextDouble();
        
        Apartments apartment4 = new Apartments(69,8, 3, 699.00);
        Scanner input4 = new Scanner(System.in);
        System.out.println("How many bedrooms do you want?");
        int bedrooms4 = input4.nextInt();
        System.out.println("How many bathrooms do you want?");
        int bathrooms4 = input4.nextInt();
        System.out.println("And the maximum rent you're looking for?");
        double rent4 = input4.nextDouble();
        
        Apartments apartment5 = new Apartments(36,9, 4, 899.00);
        Scanner input5 = new Scanner(System.in);
        System.out.println("How many bedrooms do you want?");
        int bedrooms5 = input5.nextInt();
        System.out.println("How many bathrooms do you want?");
        int bathrooms5 = input5.nextInt();
        System.out.println("And the maximum rent you're looking for?");
        double rent5 = input5.nextDouble();
        
        int count = 0;
        
        if (checkingApartments(apartment1, bedrooms1, bathrooms1, rent1))
        { //The if statemtes will check to see if each statemt is
            count++;// true for each apmt
            System.out.println("Looks like we found a match for Apmt 1! " + apartment1.getApmtNumber() + apartment1.getBathrooms() + 
                    apartment1.getBedrooms() + apartment1.getRentAmount());
        }
        if (checkingApartments(apartment2, bedrooms2, bathrooms2, rent2))
        {
            count++;
            System.out.println("Looks like we found a match or Apmt 2! " + apartment2.getApmtNumber() + apartment2.getBathrooms() + 
                    apartment2.getBedrooms() + apartment2.getRentAmount());
        }
        if (checkingApartments(apartment3, bedrooms3, bathrooms3, rent3))
        {
            count++;
            System.out.println("Looks like we found a match or Apmt 3! " + apartment3.getApmtNumber() + apartment3.getBathrooms() + 
                    apartment3.getBedrooms() + apartment3.getRentAmount());
        }
        if (checkingApartments(apartment4, bedrooms4, bathrooms4, rent4))
        {
            count++;
            System.out.println("Looks like we found a match or Apmt 4! " + apartment4.getApmtNumber() + apartment4.getBathrooms() + 
                    apartment4.getBedrooms() + apartment4.getRentAmount());
        }
        if (checkingApartments(apartment5, bedrooms5, bathrooms5, rent5))
        {
            count++;
            System.out.println("Looks like we found a match or Apmt 5! " + apartment5.getApmtNumber() + apartment5.getBathrooms() + 
                    apartment5.getBedrooms() + apartment5.getRentAmount());
        }
        
        
        if(count==0)
        { //If it comes out flase then it will print out this statement
            System.out.println("We cannot find apmt.");
        }
    }
    public static boolean checkingApartments(Apartments apartments, int userBedrooms, int userBathrooms, double userRent)
    {
            boolean result = false; //The boolean method will check to see if its true and false
            if((apartments.getBedrooms() <= userBedrooms) && (apartments.getBathrooms() <= userBathrooms) && (apartments.getRentAmount() <= userRent)){
                result = true;
            }
                
            return result;
    }
}

/*
Problem Defintion: 
 
Author: Montell N.
Date: 4/14/21
 */
package example04212021;

public class Example04212021 {
    /**
     * Test program
     * @param args 
     */

    public static void main(String[] args) {
        printName("Montell Norman");
    }
    /**
     * 
     * @param name 
     */
    
    public static void printName(String name){
        System.out.println("The name is: " + name);
    }
    
}

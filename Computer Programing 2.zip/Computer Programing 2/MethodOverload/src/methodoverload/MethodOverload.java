/*
Problem Defintion
rite a program (MethodOverload.java) that uses two functions with the same name to calculate the square of an integer and a double respectively. 
Author: Montell N.
Date: 1/2/21
 */
package methodoverload;


public class MethodOverload {

    
    public static void main(String[] args) {
        System.out.println("Square of is " + square(4) + "\n");     //Here I'm calling the functions from below with the intValue and doubleValue
        System.out.println("Square of 4.4 is " + square(4.4) + "\n"); //respectivily 
    }
    
    public static int square(int intValue){
        System.out.println("\nCalled square with int argument: " + intValue + "\n");
        return intValue*intValue; //Multiplying both the values that'll return back to line 18
        
    }
    
    public static double square(double doubleValue){
        System.out.println("\nCalled square with double argument: " + doubleValue + "\n");
        return doubleValue*doubleValue; //Similar to Line 20 I'm multiplying the double values
    }
    
}

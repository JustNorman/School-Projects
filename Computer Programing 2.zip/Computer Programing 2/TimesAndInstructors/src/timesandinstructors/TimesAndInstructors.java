/*
Problem Defintion

Author: Montell N.
Date: 3/12/21
 */
package timesandinstructors;

import javax.swing.*;

public class TimesAndInstructors {

    public static void main(String[] args) {
        String[][] courses = new String[5][3];
        
        /*
        r0c0 r0c1 r0c2
        r1c0 r1c1 r1c2
        r2c0 r2c1 r2c2
        r3c0 r3c1 r3c2
        r4c0 r3c1 r4c2
        */
        
        courses[0][0] = "CIS 101";
        courses[0][1] = "Mon 9:00 am";
        courses[0][2] = "Farrell";
        
        courses[1][0] = "CS 230";
        courses[1][1] = "Mon 12:30 pm";
        courses[1][2] = "Gosh";
        
        courses[2][0] = "CS 231 ";
        courses[2][1] = "Mon 10:00 am";
        courses[2][2] = "Ogden";
        
        String entry, message = "Enter a course";
        
        boolean isFound = false;
        int i;
        while(!isFound){
            entry = JOptionPane.showInputDialog(message);
            for(i = 0; i < courses.length; i++){
                if(entry.equals(courses[i][0])){
                    isFound = true;
                    JOptionPane.showMessageDialog(null, "Courses: " + entry + " Time: " + courses[i][1] + " Instructor: "
                    + courses[i][2]);
                }
            }
        }
        
    }
    
}

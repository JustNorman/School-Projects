/*
Problem Defintion
Submit all practice problems we discussed during 2/22's lecture. 
Author: Montell N.
Date: 2/24/21
 */
package controlstructures;

 class ControlStructures {
    
    
    public static void main(String[] args) {
        int i = 50;
        if(i > 20){//If the statement is true then the statemnt will be
            System.out.println("1 is greater than 20");//printed
        }
        else{//If the statement is false then it will not print
            System.out.println("I'm not inside if");
        }
      
        
        int j = 6;//Similar to line 13, but with a different variable
        if(j > 60){
            System.out.println("1 is greater than 20");
        }
        else if (j < 200){//This adds another condition to the problem to see if the statement is 
            System.out.println("1 is less than 20");//True or False
        }
        else{
            System.out.println("I'm inside else");
        }
        
        if(5 < 6){//nested if structure
            if(1 > 2){
                System.out.println("Both if statements are true");
            }
        }
        
        int k = 220;
        switch(k){//Multi-way brand statement that excutes the code for each expression
            case 0:
                System.out.println("i is zero");
                break;//This will tell the switch to come out of it
            case 1:
                System.out.println("i is one");
                break;
            case 2:
                System.out.println("i is two");
                break;
            default:
                System.out.println("printing switching... ");
                break;
        }
    }
    
}

/*
Problem Defintion:
More inheritance examples
Author: Montell N.
Date: 4/14/21
 */
package example04142021;

public class Example04142021 {
    
    /*Object class -->
    boolean equals (Object obj) --> Returns true if this object is an alias of the specified object
    
    String toString() --> Returns a string representation of object
    
    Object clone() --> Creates and returns a copy of this object
    */
    
    /*Restricting inheritance
    Using final key word before class name
    */
    
    /*Polymorphism:
    Having many forms
    A polymorphic refrence is refrence variable that can refer to different
    types of object at different points in time.
    --> We can create a polymorphic refrence in Java in two ways:
    using inheritance, using interfaces.
    
    Late binding/dynamic binding: It happens during time
    */
    
    public static void main(String[] args) {
        Animal myAnimal = new Animal();
        Animal myCow = new Cow();
        Animal myDuck = new Duck();
        
        myAnimal.createSound();
        myCow.createSound();
        myDuck.createSound();
    }
    
}

class Animal{
    public void createSound(){
        System.out.println("Animal Says:");
    }
}

class Cow extends Animal{
    public void createSound(){
        System.out.println("Cow: Moo!");
    }
}

class Duck extends Animal{
    public void createSound(){
        System.out.println("Duck: Quack!");
    }
}
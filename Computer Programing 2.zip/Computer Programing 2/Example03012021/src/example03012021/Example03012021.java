/*
Problem Defintion
Submit all practice problems we discussed during 3/3's lecture. 
Author: Montell N.
Date: 3/3/21
 */
package example03012021;

public class Example03012021 {
    
    public static void main(String[] args) {
        String myStr1 = "JSU";
        String myStr2 = new String("JSU");
        if(myStr1 == myStr2){ //Comparing addresses
            System.out.println(myStr1 + " equals " + myStr2);
        }
        else{
            System.out.println(myStr1 + " does not equal " + myStr2);
        }
        
        String myStr3 = "JSU";
        String myStr4 = new String("JSU");
        if(myStr3 == myStr4){ //Comparing addresses
            System.out.println(myStr3 + " equals " + myStr4);
        }
        else{
            System.out.println(myStr3 + " does not equal " + myStr4);
        }
        
        String myStr5 = "JSU";
        String myStr6 = new String("JSU").intern();
        if(myStr5 == myStr6){ //Comparing addresses
            System.out.println(myStr5 + " equals " + myStr6);
        }
        else{
            System.out.println(myStr5 + " does not equal " + myStr6);
        }
        
        //Character methods
        System.out.println("Character methods: ");
        
        char ch = '9';
        //isUpperCase() isLowercase
        if(Character.isUpperCase(ch)){
            System.out.println(ch + " is Upper case.");
        }
        else if(Character.isLowerCase(ch)){
            System.out.println(ch + " is Lower case");
        }
        else if(Character.isDigit(ch)){
            System.out.println(ch + " is a digit.");
        }
        else{
            System.out.println(ch + " is not a character.");
        }
        
        //isLetter(), isLetterorDigit(), isWhitespace() ###-###-####
        
        //String methods
        String str = "Hello World";
        System.out.println("The length of the string is " + str.length());
        
        //charAT()
        System.out.println("Using charAT(): " + str.charAt(4));
        
        //substring()
        System.out.println("Using substring(): " + str.substring(1, 4));
        
        //contains()
        System.out.println("Using contains(): " + str.contains("Hello"));
        
        //startsWith(), endsWith(), indexOf(), concat(), CompareTo(), toUpperCase(), toLowerCase(), ...
        
        //StringBuilder methods
        StringBuilder str2 = new StringBuilder("This is JSU!");
        System.out.println(str2);
        System.out.println(str2.reverse());//returns the StringBuilder
        System.out.println(str2.append('!'));
        //toString(), setCharAt(), deleteCharAt(),replace()
        
        //StringBuffer methods
        StringBuffer str3 = new StringBuffer("This is CS232!");
        System.out.println(str3);
        System.out.println("The length of the string is " + str3.length());
        System.out.println("Using capacity(): " + str3.capacity());//Returns the current capacity of the char
        System.out.println("Using charAT(): " + str3.charAt(2));
    }
    
}

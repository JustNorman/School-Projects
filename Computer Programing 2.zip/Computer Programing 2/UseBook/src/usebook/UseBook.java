/*
Problem Defintion: 
Write an application demonstrating that you can create both a Fiction and a NonFiction Book, and display their fields. 
Save the files as Book.java, Fiction.java, NonFiction.java, and UseBook.java.
Author: Montell N.
Date: 4/14/21
 */
package usebook;

public class UseBook {
    
    public static void main(String[] args) {
        Book myBook = new Fiction("SCP Foundation");
        Book myBook2 = new NonFiction("Area 51");
        
        //Displays the details of the books
        System.out.println(myBook.getBookTitle() + " costs:$ " + myBook.getBookPrice());
        System.out.println(myBook2.getBookTitle() + " costs:$ " + myBook2.getBookPrice());
    }
    
}

/*
Problem Defintion: 
Create two child classes of Book: Fiction and NonFiction. 
Each must include a setPrice() method that sets the price for all Fiction Books to $24.99 and for all NonFictionBooks to $37.99. 
Write a constructor for each subclass, and include a call to setPrice() within each. 
Author: Montell N.
Date: 4/14/21
 */
package usebook;

//Child class to Book
public class NonFiction extends Book{
    public NonFiction(String bookTitle){
        super(bookTitle); //Calling the super class constructor
        setBookPrice();
    }
    
    public void setBookPrice(){
        bookPrice = 37.99;
    }
}

/*
Problem Defintion
3) FlipRace.java:
Demonstrates the reuse of programmer-defined class. 
Flips two coins until one of them comes up heads three times in a row. 
- Use constant integer, while loop, 
Date: 2/26/21
 */
package fliprace;

public class FlipRace {

    public static void main(String[] args) {
        final int GOAL = 3; //Constant Variable
        
        int count1 = 0, count2 = 0;
        
        Coin coin1 = new Coin(); //Class objects for the coin constructor
        Coin coin2 = new Coin();
        
        while(count1 != GOAL && count2 != GOAL){ //A while loop will check for the number of heads and tails for both coins
            coin1.flip();
            coin2.flip();
            
            System.out.println("Coin 1: " + coin1 + "\tCoin 2: " + coin2);
            
            //increment or reset the counters
            count1 = (coin1.isHeads()) ? count1 + 1 : 0;
            count2 = (coin2.isHeads()) ? count2 + 1 : 0;
        }
        
        if(count1 < GOAL){ //Each if statement will check each coin to see if its true or false
            System.out.println("Coin 2 wins!"); // If count1 is less than the goal then it will print out this statement
        }
        else{
            if(count2 < GOAL){ // If count2 is less than the goal then it will print out this statement
                System.out.println("Coin 1 wins!");
            }
            else{ // If both statemnt are true or flase then its a Tie
                System.out.println("It's a TIE!");
            }
        }
    }
    
}

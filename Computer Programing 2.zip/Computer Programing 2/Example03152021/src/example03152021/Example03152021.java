/*
Problem Defintion
Java Enums (enumerations)
Author: Montell N.
Date: 3/15/21
 */
package example03152021;

public class Example03152021 {
    
    /*
    An enum is a special class that can contain a set of constants (you can't change, similar like
    final var).
    
    To create an enum, use enum keyboard.
    enum daysofweek{
        SUNDAY,
        MONDAY,
        TUESDAY,
    
    }
    
    enum level{
        HIGH,
        MEDIUM,
        LOW,
    
    }
    
    Differences between Enums and Classes: Both can have attributes and methods. The only difference is that
    enum constanrs are public, static, and final.
    You cannot create objects using enum. You cannot extend and create another enum.
    
    */
    
    enum level{
        HIGH,
        MEDIUM,
        LOW
    }
    
    enum daysOfWeek{
        SUNDAY("Su"),
        MONDAY("M"),
        TUESDAY("T"),
        WEDNESDAY("W"),
        THURSDAY("TR"),
        FRIDAY("F"),
        SATURDAY("Sa");
        
        private final String dayCode;
        
        daysOfWeek(String dayCode){
            this.dayCode = dayCode;
        }
        
        public String getDayCode(){
            return this.dayCode;
        }
    }
    
    level myLevel = level.HIGH;

    public static void main(String[] args) {
        level myLevel = level.LOW;
        
        /*if(myLevel == level.HIGH){
            System.out.println("You chose Low");
        }*/
        
        //switch(myLevel) //provide an example
        
        //Enum iteration
        for(level lev: level.values()){
            System.out.println(lev);
        }
        
        //Enum toString()
        String levText = level.LOW.toString();
        System.out.println(levText);
        System.out.println(level.LOW);
        
        //Enum valueOf() - use to obtain an enum type object for a given string value
        level myLevel2 = level.valueOf("MEDIUM");
        
        //Enum Fields --> each constant enum value will get these fields. Use enum constructor to provide field values
        daysOfWeek myDay = daysOfWeek.THURSDAY;
        System.out.println(myDay.getDayCode());
        
        
        
    }
    
}

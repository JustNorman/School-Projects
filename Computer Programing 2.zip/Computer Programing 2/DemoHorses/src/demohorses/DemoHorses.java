/*
Problem Defintion
Write an application (DemoHorses.java) that demonstrates the concept of inheritance using above classes. 
Author: Montell N.
Date: 4/7/21
 */
package demohorses;

public class DemoHorses {

    public static void main(String[] args) {
        Horse horse1 = new Horse("Steven Bills");
        horse1.setColor("Brown");
        horse1.setBirthyear(1996);
        System.out.println(horse1.getName() + " is " + horse1.getColor() + " and was born in " + horse1.getBirthYear());
        
        RaceHorse horse2 = new RaceHorse("Bill Jobs", 20);
        horse2.setColor("Black");
        horse2.setBirthyear(2000);
        System.out.println(horse2.getName() + " is " + horse2.getColor() + " and was born in " + horse2.getBirthYear() + 
                " and has been in " + horse2.getRaces() + " races.");
    }
    
}

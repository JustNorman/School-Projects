/*
Problem Defintion
Next, create a subclass named RaceHorse (RaceHorse.java), which contains an additional field that holds the number of races in which the horse has competed and additional methods to get and set the new field. 
Make sure that the constructor of this class stores the name of the horse by invoking base-class(Horse) constructor. 
The child class constructor should get the number of races as another argument.
Author: Montell N.
Date: 4/7/21
 */
package demohorses;

//Child class
public class RaceHorse extends Horse{
    
    private int races;
    public RaceHorse(String name, int races) {
        super(name); //Calling the constuctor of the parent class
        this.races = races;
    }

    public int getRaces() {
        return races;
    }

    public void setRaces(int races) {
        this.races = races;
    }
    
    //Overide toString
     public String getColor(){
         return color;
     }
    
    public int getBirthYear(){
        return birthyear;
    }

    public String getName() {
        return name;
    }
    
    
}

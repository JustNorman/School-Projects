/*
Problem Defintion
Create a class named Horse (Horse.java) that contains data fields such as the name, color, and birth year. 
Include constructor that helps to save the name of the horse. Also add get and set methods. 
Author: Montell N.
Date: 4/7/21
 */
package demohorses;

//Parent class
public class Horse {
    //data fields
    protected String name;
    protected String color;
    protected int birthyear;
    
    public Horse(String name){
        this.name = name;
    }
    
    public String getColor(){
         return color;
     }
    
    public int getBirthYear(){
        return birthyear;
    }

    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setBirthyear(int birthyear) {
        this.birthyear = birthyear;
    }
    
    //toString
    
    
}

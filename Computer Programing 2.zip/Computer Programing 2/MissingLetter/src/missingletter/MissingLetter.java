/*
Problem Defintion: 
Create a function that takes an array of increasing letters and return the missing letter.
Author: Montell N.
Date: 4/14/21
 */
package missingletter;

import java.util.*;

public class MissingLetter {

    public static void main(String[] args) {
        String[] missingLetter = new String[]{"m","n","p","q","r","s"};
        System.out.println(checkArray(missingLetter));
    }
    
    //Method to receive array
    public static String checkArray(String[] array){
        for(int i = 1; i < array.length; i++){
            if(array[i].charAt(0)!= array[i-1].charAt(0) + 1){
                return Character.toString((char)(array[i].charAt(0)-1));
            }
        }
        return "Could not find character.";
    }
}

/*
Author: Martell N.
Date: 4/7/22
 */
package phonenumbers;

import java.util.Scanner;

public class PhoneNumbers 
{
    
    public static void main(String[] args) 
    {
        //String Arrays for both names and phones
        String[] names = new String[30];
        String[] phNumbers = new String[30];
        boolean nameFound = false;
        int maximumNmb = 10;
        
        //Assigning names arrary and phones array
        names[0] = "Andy";
        names[1] = "Mausam";
        names[2] = "Montell";
        names[3] = "Ruri";
        names[4] = "James";
        names[5] = "Tyler";
        names[6] = "Jordan";
        names[7] = "Ruri";
        names[8] = "Sam";
        names[9] = "Maxis";
        
        phNumbers[0] = "(334)825-4206";
        phNumbers[1] = "(334)435-2087";
        phNumbers[2] = "(334)275-5479";
        phNumbers[3] = "(334)206-6987";
        phNumbers[4] = "(334)420-6924";
        phNumbers[5] = "(334)738-8317";
        phNumbers[6] = "(334)194-2185";
        phNumbers[7] = "(334)256-5897";
        phNumbers[8] = "(334)123-6547";
        phNumbers[9] = "(334)246-8101";
        
        //Asking the user input data
        Scanner input = new Scanner(System.in);
        System.out.println("Please type the name of the person and I'll give you their"
                + "phone number.");
        String personNme = input.nextLine();
        
        //Looping through the array
        while(maximumNmb < 30 && !personNme.equals("quit"))
        {
            for(int i = 0; i < maximumNmb; i++)
            {
                if(personNme.equals(names[i]))
                {
                    nameFound = true;
                    System.out.println("Found it!"); //if its found
                    System.out.println(phNumbers[i]);
                }
            }
            //if its not found
            if(!nameFound)
            {
                Scanner number = new Scanner(System.in);
                System.out.println(personNme + " does not exist. Please enter a phone number: ");
                String phoneNumbers = number.nextLine();
                phNumbers[maximumNmb] = phoneNumbers;
                names[maximumNmb] = personNme;
                ++maximumNmb;
            }
            if(maximumNmb == 30)
            {
                System.out.println("Sorry it has reached our maximum capcity."
                        + " The Number list is now full.");
            }
            System.out.println("Please enter another name: (Type 'quit' if you want to stop)");
            personNme = input.nextLine();
            
            nameFound = false;
            
        }
    }
    
}

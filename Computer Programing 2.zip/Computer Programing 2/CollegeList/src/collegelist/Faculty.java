/*
Problem Defintion:
• Faculty—Faculty descends from CollegeEmployee. This class also includes a Boolean field that indicates whether the Faculty member is tenured, 
as well as methods that override the CollegeEmployee methods to accept and display this additional piece of information. 
Author: Montell N.
Date: 4/7/21
 */
package collegelist;

import java.util.*;

//Child class to CollegeEmployee
public class Faculty extends CollegeEmployee{
    //Data fields
    protected boolean isTenured = false;
    
    @Override
    public void setPerson(){
        String tenured;
        
        super.setPerson();
        Scanner input = new Scanner(System.in);
        System.out.println("Are you Tenured(y/n)?");
        tenured = input.nextLine();
        
        if(tenured.equalsIgnoreCase("y")){
            isTenured = true;
        }
        else{
            isTenured = false;
        }
    }
    
    @Override
    public void displayDataFields(){
        super.displayDataFields();
        if(isTenured == true){
            System.out.println("This person is tenured.");
        }
        else{
            System.out.println("This person is not tenured.");
        }
    }
}

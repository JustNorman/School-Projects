/*
Problem Defintion: 
•CollegeEmployee—CollegeEmployee descends from Person. A CollegeEmployee also includes a Social Security number, 
an annual salary, and a department name, as well as methods that 
override the Person methods to accept and display all CollegeEmployee data. 
Author: Montell N.
Date: 4/7/21
 */
package collegelist;

import java.util.*;

//Child and Parent class
public class CollegeEmployee extends Person{
    //Data fields
    protected String ssn;
    protected double salary;
    protected String departName;
    
    //Overide
    @Override //Overriding the parent methods
    public void setPerson(){
        String anSalary;
        
        super.setPerson();
        Scanner input = new Scanner(System.in);
        System.out.println("What is your Social Security Number?");
        ssn = input.nextLine();
        System.out.println("What is your annual Salary?");
        anSalary = input.nextLine();
        salary = Double.parseDouble(anSalary);
        System.out.println("What is your department name?");
        departName = input.nextLine();
    }
    
    @Override //Overriding the parent methods
    public void displayDataFields(){
        super.displayDataFields();
        System.out.println("SSN: " + ssn + " \nDepartment: " + departName + " \nAnnual Salary: " + salary);
    }
}

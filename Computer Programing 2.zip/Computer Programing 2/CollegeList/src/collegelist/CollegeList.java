/*
Problem Defintion:
In CollegeList declare an array of four“regular” CollegeEmployees, three Faculty, and seven Students. 
Prompt the user to specify which type of person’s data will be entered (C, F, or S), or allow the user to quit (Q). 
While the user chooses to continue (that is, does not quit), accept data entry for the appropriate type of Person. 
If the user attempts to enter data for more than two CollegeEmployees, one Faculty, or five Students, display an error message. 
When the user quits, display a report on the screen listing each group of Persons under the appropriate heading of “College Employees,” “Faculty,” or “Students.” 
If the user has not entered data for one or more types of Persons during a session, display an appropriate message under the appropriate heading. 
Author: Montell N.
Date: 4/7/21
 */
package collegelist;

import java.util.*;

public class CollegeList {

    public static void main(String[] args) {
        CollegeEmployee[] collegeEmployee = new CollegeEmployee[4]; //Creating a CollegeEmployee array
        Faculty[] faculty = new Faculty[3]; //Creating Faculty array
        Student[] student = new Student[7]; //Creating Student array
        
        Scanner input = new Scanner(System.in);
        //Declaring other variables
        String userInput;
        char letter;
        int countingCollege = 0;
        int countingFaculty = 0;
        int countingStudent = 0;
        do{ //Repeats the loop until the user quits
            System.out.println("Please enter the type of person you want to enter. 'C' for College Employee, 'F' for Faculty, 'S' for"
                    + "Student, or 'Q' if you want to exit.");
            userInput = input.nextLine();
            letter = userInput.charAt(0);
            switch(letter){
                case 'C':
                case 'c':
                    if(countingCollege < collegeEmployee.length){
                        CollegeEmployee collegeEmployee1 = new CollegeEmployee();
                        collegeEmployee1.setPerson();
                        collegeEmployee[countingCollege] = collegeEmployee1;
                        countingCollege++;
                    }
                    else{
                        System.out.println("The information you have enter has exceeded the length.");
                    }
                    break;
                case 'F':
                case 'f':
                    if(countingFaculty < faculty.length){
                        Faculty faculty1 = new Faculty();
                        faculty1.setPerson();
                        faculty[countingFaculty] = faculty1;
                        countingFaculty++;
                    }
                    else{
                        System.out.println("The information you have enter has exceeded the length.");
                    }
                    break;
                case 'S':
                case 's':
                    if(countingStudent < student.length){
                        Student student1 = new Student();
                        student1.setPerson();
                        student[countingStudent] = student1;
                        countingStudent++;
                    }
                    else{
                        System.out.println("The information you have enter has exceeded the length.");
                    }
                    break;
                case 'Q':
                case 'q':
                    break;
                default:
                    System.out.println("Invalid letter.");
                    break;
            }
        }
        while(letter != 'Q' && letter != 'q');
        System.out.println("\n****REPORT****");
        System.out.println("\nCollege Employees...");
        if(countingCollege == 0){ //Verifies the number of College Employee
            System.out.println("There's no data in College Employees");
        }
        else{
            for(int i = 0; i < countingCollege; i++){
                System.out.println((i + 1) + ": ");
                collegeEmployee[i].displayDataFields();
                System.out.println();
            }
        }
        System.out.println("\nFaculty...");
        if(countingFaculty == 0){ //Verifies the number of Faculty
            System.out.println("There's no data in Faculty");
        }
        else{
            for(int i = 0; i < countingFaculty; i++){
                System.out.println((i + 1) + ": ");
                faculty[i].displayDataFields();
                System.out.println();
            }
        }
        System.out.println("\nStudents...");
        if(countingStudent == 0){ //Verifies the number of Student
            System.out.println("There's no data in Student");
        }
        else{
            for(int i = 0; i < countingFaculty; i++){
                System.out.println((i + 1) + ": ");
                student[i].displayDataFields();
                System.out.println();
            }
        }
    }
}

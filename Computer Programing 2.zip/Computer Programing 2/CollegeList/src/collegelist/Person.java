/*
Problem Defintion:
• Person—A Person contains a first name, last name, street address, zip code, and phone number. 
The class also includes a method that sets each data field, using a series of dialog boxes and a display
method that displays all of a Person’s information on a single line at the command line on the screen. 
Author: Montell N.
Date: 4/7/21
 */
package collegelist;

import javax.swing.JOptionPane;

//Parent Class
public class Person {
    //Data fields
    protected String fName;
    protected String lName;
    protected String address;
    protected String zip;
    protected String phoneNum;
    
    public void setPerson(){ //Dialog boxs for each question
        fName = JOptionPane.showInputDialog(null, "What is your first name?");
        lName = JOptionPane.showInputDialog(null, "What is your last name?");
        address = JOptionPane.showInputDialog(null, "What is your address?");
        zip = JOptionPane.showInputDialog(null, "What is your zip code?");
        phoneNum = JOptionPane.showInputDialog(null, "What is your phone number?");
    }
    
    //Display method
    public void displayDataFields(){ //Display methods with all the givien information
        System.out.println("This person's full name is " + fName +" " + lName + "\nTheir home address: " + address + "\n Zip Code: " + zip + 
                "\nPhone Number: " + phoneNum);
    }
}

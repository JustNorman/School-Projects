/*
Problem Defintion:
• Student—Student descends from Person. In addition to the fields available in Person, a Student contains a major field of study and a 
grade point average as well as methods that override the Person methods to accept and display these additional facts. 
Author: Montell N.
Date: 4/7/21
 */
package collegelist;

import java.util.*;

//Child class to Person
public class Student extends Person{
    //Data fields
    private String major;
    private String gpa;
    
    //Override
    @Override
    public void setPerson(){
        super.setPerson(); //Access to the parent class setPerson method
        Scanner input = new Scanner(System.in);
        System.out.println("What is your major of study?");
        major = input.nextLine();
        System.out.println("What is your GPA?");
        gpa = input.nextLine();
    }
    
    //Override
    @Override
    public void displayDataFields(){
        super.displayDataFields(); //Access to the parent class display method
        System.out.println("This person's Major of Study is: " + major + " and his GPA is: " + gpa);
    }
}

/*
Problem Defintion
Create a class named Person that holds the following fields: two String objects for the person’s first and last name and a LocalDate object for the person’s birthdate. 
Create a class named Couple that contains two Person objects. 
Create a class named Wedding for a wedding planner that includes the date of the wedding, the names of the Couple being married, and a String for the location. 
Provide constructors for each class that accept parameters for each field, and provide get methods for each field. 
Then write a program that creates two Wedding objects and in turn passes each to a method that displays all the details. 
Save the files as Person.java, Couple.java, Wedding.java, and TestWedding.java. 
Author: Martell N.
Date: 2/20/22
 */
package testwedding;

import java.time.LocalDate;
import java.time.Month;


public class TestWedding 
{


    public static void main(String[] args) 
    {
        //Person.java and Couple.java class objects
        LocalDate bDate1 = LocalDate.of(2000,5,6);//These two dates are the birthdates for the two couples
        LocalDate bDate2 = LocalDate.of(2001,12,8);
        Person groom = new Person("Jake","Smith", bDate1);//The couples themselves are pulled from the Person.java constructor
        Person bride = new Person("Lili","Norman", bDate2);
        
        
        //Wedding.java class objects
        LocalDate wDate = LocalDate.of(2021,5,6);//The wedding dates for the couples
        //weddingLocation wLocation = new weddingLocation("Washington"); //Could not figure out what was wrong with this line
        
        
        System.out.println("Bride first name: " + bride.getFirstName() + " \nlast name: " + bride.getlastName() + "\nBirth date: " + bride.getBirthDate());
        System.out.println("Groom first name: " + groom.getFirstName() + " \nlast name: " + groom.getlastName() + "\nBirth date: " + groom.getBirthDate());
        System.out.println("Wedding date: " + wDate);
        //System.out.println("Wedding Location: " + wLocation.getweddingLocation()); //Similar problem to line 31
    }
    
}

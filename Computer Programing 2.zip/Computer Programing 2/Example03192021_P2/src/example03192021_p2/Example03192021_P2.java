/*
Problem Defintion
Demostrates the uses of Variable length parameter lists
Author: Montell N.
Date: 3/19/21
 */
package example03192021_p2;

public class Example03192021_P2 {

    public static void main(String[] args) {
        Family norman = new Family("Montell Norman", "Martell Norman", "Jaiden Lester", "Jailen Lester", "CJ Lester");
        Family simpson = new Family("Naquinta Simpson", "James Simpson", "Josephine Simpson", "Khari Simpson", "Christopher Lester");
        
        System.out.println(norman);
        System.out.println();
        System.out.println(simpson);
    }
    
}

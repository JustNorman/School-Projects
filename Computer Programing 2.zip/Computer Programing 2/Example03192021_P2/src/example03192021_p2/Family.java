/*
Problem Defintion
Demostrates the uses of Variable length parameter lists
Author: Montell N.
Date: 3/19/21
 */
package example03192021_p2;

public class Family {
    private String[] members;
    
    //Constructor
    public Family(String...names){
        members = names;
    }
    
    public String toString(){
        String result = "";
        for(String name: members){
            result += name + "\n";
        }
        return result;
    }
}

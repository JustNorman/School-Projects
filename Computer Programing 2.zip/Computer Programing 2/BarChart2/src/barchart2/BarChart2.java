/*
Author: Martell N.
Date: 3/13/22
 */
package barchart2;

import java.util.Scanner;

public class BarChart2 
{

    public static void main(String[] args) 
    {
        int Art; //Creating class objects
        int Bob;
        int Cal;
        int Dan;
        int Eli;
        
        //Aksing the user input for the score they earned
        Scanner score = new Scanner(System.in);
        System.out.println("Please enter the amount of point scored by Art: ");
        Art = score.nextInt();
        System.out.println("Please enter the amount of point scored by Bob: ");
        Bob = score.nextInt();
        System.out.println("Please enter the amount of point scored by Cal: ");
        Cal = score.nextInt();
        System.out.println("Please enter the amount of point scored by Dan: ");
        Dan = score.nextInt();
        System.out.println("Please enter the amount of point scored by Eli: ");
        Eli = score.nextInt();
        
        seasonPoints("Art", Art); //The for loop structure below will calculate the amount of
        seasonPoints("Bob", Bob); //points and it will output it into stars
        seasonPoints("Cal", Cal);
        seasonPoints("Dan", Dan);
        seasonPoints("Eli", Eli);
        
    }
    
    public static void seasonPoints(String playerName, int playerPoints)
    {
        System.out.print("\n" + playerName);
        for(int i = 0; i < playerPoints / 10; i++)
        {
            System.out.print("*");
        }
    }
    
}

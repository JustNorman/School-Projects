/*
Problem Defintion:
Advanced Inheritance Examples
Author: Montell N.
Date: 4/16/21
 */
package example04162021;

public class Example04162021 {

    public static void main(String[] args) {
        //This is not allowed if the class is abstract
        //Animal myAnimal = new Animal();
        Animal myCow = new Cow();
        Animal myDuck = new Duck();
        
        //myAnimal.createSound();
        myCow.createSound();
        myCow.sayHi();
        
        myDuck.createSound();
        myDuck.sayHi();
        
        System.out.println("\n\n");
        Animal[] myAnimals = {new Cow(), new Duck(), new Duck(), new Cow()};
        
        for(Animal a: myAnimals){
            a.createSound();
            a.sayHi();
        }
        
        System.out.println("\n\n");
        Pirahna myPirahna = new Pirahna();
        System.out.println(myPirahna.hasTeeth());
        myPirahna.sayHi();
    }
    
}

abstract class Animal{
    //Abstract Methods (do not have a body)
    public abstract void createSound();
    //Regular Methods
     public void sayHi(){
        System.out.println("HI!");
    }
}

class Cow extends Animal{
    public void createSound(){
        System.out.println("Cow: Moo!");
    }
    public void sayHi(){
        System.out.println("HI!");
    }
}

class Duck extends Animal{
    public void createSound(){
        System.out.println("Duck: Quack!");
    }
     public void sayHi(){
        System.out.println("HI!");
    }
}

//Interface example
interface Fish{
    public boolean hasTeeth();
}

interface Animal2{
    public void sayHi();
}
class Pirahna implements Fish, Animal2{ //Achieving multiple inheritance
    public boolean hasTeeth(){
        return true;
    }
    public void sayHi(){
        System.out.println("HI!");
    }
}
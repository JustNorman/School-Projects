/*
Problem Defintion
1) Coin.java: 
Create a class that represents a coin with two sides that can be flipped. 
- Use Math.random(), toString(), conditional operator ?: (which can be thought of as shorthand for an if-then-else statement)
Author: Montell N.
Date: 2/26/21
 */
package countflips;

public class Coin {
    private final int HEADS = 0; //tails will be 1
    private int face; //current side showing
    
    //constructor
    public Coin(){
        flip(); //will call the flip function
    }
    
    public void flip(){
        face = (int)(Math.random() * 2); //This will genrate a random number
    }
    
    //boolean function
    public boolean isHeads(){
        return(face == HEADS); //This expression will give out a true of false statement if it return 0 or 1
    }
    
    //Overide
    public String toString(){
        return(face == HEADS)? "Heads" : "Tails";
    }
}

/*
Problem Defintion
2) CountFlips.java:
Demonstrates the use of programmer-defined class. 
Flips a coin multiple times and counts the number of heads and tails that result. 
- Use for loop, if-else, constant integer, conditional operator ?:
Author: Montell N.
Date: 2/26/21
 */
package countflips;

public class CountFlips {

    public static void main(String[] args) {
        final int FLIPS = 1000; //This will count the number of flips in total for 
        int heads = 0, tails = 0; //both heads and tails
        
        
        Coin coin1 = new Coin(); //Class objects for the coin constructor
        
        for(int count = 1; count <= FLIPS; count++){
            coin1.flip(); //Calling the flip function
            
            if(coin1.isHeads()){
                heads++; //If heads, true
            }
            else{
                tails++; //If not heads, then false 
            }
        }
        
        System.out.println("Number of flips: " + FLIPS);
        System.out.println("Number of Heads: " + heads);
        System.out.println("Number of Tails: " + tails);
    }
    
}

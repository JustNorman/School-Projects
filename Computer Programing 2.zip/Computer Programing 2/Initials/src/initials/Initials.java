/*
Problem Defintion
Write a program that computes your initials from your full name and displays them.
Author: Montell N.
Date: 3/3/21
 */
package initials;

public class Initials {

    public static void main(String[] args) {
        String name = "Montell Norman";
        StringBuffer initials = new StringBuffer();
        
        for(int i = 0; i < name.length(); i++){
            if(Character.isUpperCase(name.charAt(i))){
                initials.append(name.charAt(i));
            }
        }
        System.out.println("The initials are: " + initials);
    }
    
}

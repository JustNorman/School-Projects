/*
Problem Defintion
a. Create a FitnessTracker class that includes data fields for a fitness activity, the number of minutes spent participating, and the date.
The class includes methods to get each field. 
In addition, create a default constructor that automatically sets the activity to running, the minutes to 0, and the date to January 1 of the current year.
Save the file as FitnessTracker.java. 
Create an application that demonstrates each method works correctly, and save it as TestFitnessTracker.java.

b. Create an additional overloaded constructor for the FitnessTracker class you created in Exercise a.
This constructor receives parameters for each of the data fields and assigns them appropriately.
Add any needed statements to the TestFitnessTracker application to ensure that the overloaded constructor works correctly, save it, and then test it.
Author: Montell N.
Date: 2/3/21
 */
package fitnesstracker;

import java.time.LocalDate;
import java.time.Month;


public class TestFitnessTracker {
    
    
    public static void main(String[] args) {
        FitnessTracker exercise = new FitnessTracker();
        System.out.println(exercise.getActivity() + ": " + exercise.getMinutes() + " Minutes on " + exercise.getDate());//The constructor/blueprint from FitnessTracker is now compile
        //To print the class varibles and the LocalDate for the object varibles as Strings
        LocalDate date = LocalDate.of(2021, 1, 15);
        
        FitnessTracker exercise2 = new FitnessTracker("Bicycling ", 35, date);
        System.out.println(exercise2.getActivity() + ": " + exercise2.getMinutes() + " Minutes on " + exercise2.getDate());
        
        FitnessTracker exercise3 = new FitnessTracker("Boxing ", 60, date);
        System.out.println(exercise3.getActivity() + ": " + exercise3.getMinutes() + " Minutes on " + exercise3.getDate());
    }
}

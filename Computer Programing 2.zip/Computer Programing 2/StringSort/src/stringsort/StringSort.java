/*
Problem Defintion

Author: Montell N.
Date: 3/12/21
 */
package stringsort;

import java.util.Arrays;
import javax.swing.*;

public class StringSort {

    public static void main(String[] args) {
        String[] strArray = {"mouse", "Keyboard", "Circuits", "RAM", "Motherboard"};
                
                
                
        //Sort srtArray
        System.out.printf("Sorted array: %s ", Arrays.toString(strArray));
        
        //Ehanced for-loop
        for(String str: strArray){
            System.out.println(str);
        }
        
        System.out.println(Arrays.toString(strArray));
        
        JOptionPane.showMessageDialog(null, Arrays.toString(strArray));
    }
    
}

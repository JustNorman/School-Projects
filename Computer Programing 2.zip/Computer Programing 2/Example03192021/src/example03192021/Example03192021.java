/*
Problem Defintion
Variable-Length Parameter Lists
Author: Montell N.
Date: 3/19/21
 */
package example03192021;

public class Example03192021 {

    public static void main(String[] args) {
        double mean1 = average(5, 33, 4, 23);
        double mean2 = average(56, 34, 23, 23, 43, 34, 87);
        
        //Use overloads versions of the average method --> this solution does not scale to abritary set if input values
        
        //Alternatively, we could define average to accept ab array of integers, which could be of different sizes for each call
        //But that would require the calling method to package the integers into an array.
        
        //In Java, there is a way to define methods that accept variable length Parameter Lists.
        //To accomplish this, we have to use some special syntax.
        //If you use this syntax, then the parameters are automatically put into an array for easy processing in the method.
        
        System.out.println(mean1);
        System.out.println(mean2);
        System.out.println(average(56, 34, 23, 23, 43, 34, 87, 420, 69, 34, 89, 1235));
        
        
    }
     public static double average(int...list){
         double result = 0.0;
         
         
         if(list.length != 0){
             int sum = 0;
             for(int num: list){
                 sum += num;
             }
             result = (double)sum/list.length;
         }
         
         
         return result;
     }
}

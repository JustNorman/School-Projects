package getuserinfo;

import java.util.Scanner; //The Scanner that's being imported is used to create an object
public class GetUserInfo {

    public static void main(String[] args) {
        String name;
        int age;
        Scanner inputDevice = new Scanner(System.in);
        System.out.print("Please enter your name >> ");
        name = inputDevice.nextLine(); // The 'nextLine()' method is used by the Scanner to register the user inputs
        System.out.print("Please enter your age >> ");
        age = inputDevice.nextInt();
        System.out.println("Your name is " + name +
                " and you are " + age + " years old.");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example03312021;

import java.util.Arrays;

public class Example03312021 {

    public static void main(String[] args) {
        //Problem 1:
        int[] myarr = {5, 10, 15, 25};
        System.out.println(sum(myarr));
        
        //Problem 2:
        int[] myarr2 = {5, 10, 15, 25};
        System.out.println(sum(myarr2));
        
        //Problem 3:
        System.out.println(countSentenceWords("This is JSU"));
    }
    
    //Problem 1:
    //Write a function that finds the sum of an array.
    //Make your function recursive
    //sum ({}) = 0
    //sum ([2,5,6}) = 3
    
    public static int sum(int[] arr){
        if(arr.length == 0){
            return 0;
        }
        return arr[0] + sum(Arrays.copyOfRange(arr, 1, arr.length));
        //arr[0] --> 2
        //return 2 + sum({5, 6})
        //return 2 + 5 + sum({6})
        //return 2 + 5 + 6 + sum({})
        //return 2 + 5 + 6 + 0
        //13
    }
    
    
    //Problem 2:
    /*
    Create a function that takes an array of numbers and returns the mean (average) of all those numbers.
    mean({3, 3, 3, 3}) --> 3.00
    mean({2, 3, 2, 3}) --> 2.50
    */
    
    public static double mean(int[] nums){
        double sum = 0.0;
        for(int i: nums){
            sum = sum + i;
        }
        return sum/nums.length;
    }
    
    //Problem 3:
    /*
    Create a method that takes a string and returns the word count. The string will be a sentence.
    countSentenceWords("This is JSU") --> 3
    */
    public static int countSentenceWords(String sentence){
        String[] words = sentence.split(" ");
        return words.length;
    }
}

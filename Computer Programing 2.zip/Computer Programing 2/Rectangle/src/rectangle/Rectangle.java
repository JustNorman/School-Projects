/*
Problem Defintion
Given the length and width of a rectangle, your java program should compute and output the perimeter and area of the rectangle
Your code should ask for the length and width at the very beginning 
Author: Montell N.
Date: 1/22/21
 */
package rectangle;

import java.util.Scanner;

public class Rectangle {


    public static void main(String[] args) {
        double length; //Lines 16, 17, 18, and 19 use the double method to declare a specify a type for the variable
        double width;
        double perimeter; 
        double area; 
        
        
        Scanner input = new Scanner(System.in); //The scanner is used to recgonized the user imputs
        
        System.out.println("What is the length? ");
        length = input.nextDouble();
        
        System.out.println("What is the width? ");
        width = input.nextDouble(); 
        
        perimeter = 2 * (length +  width); //The method here is multiplying both varibales by stringing them together to get the perimeter and area
        area = length * width;
        
        System.out.println("The perimeter of the rectangle is " + perimeter + " and the area is " + area + " unit^2.");
   }
    
}

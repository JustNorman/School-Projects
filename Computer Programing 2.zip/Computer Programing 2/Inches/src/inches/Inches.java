/*
Problem Defintion
Given length in inches,  your program "Inches.java" should output the equivalent length in feet and remaining inch(es)
Your code should prompt the user to provide the length in inches at the very beginning
Author: Montell N.
Date: 1/24/21
 */
package inches;

import java.util.Scanner;

public class Inches {


    public static void main(String[] args) {
        double length; //Lines 16, 17, 18, and 19 use the double method to declare a specify a type for the variable
        double width;
        double feet; 
        double inches; 
        
        
        Scanner input = new Scanner(System.in); //The scanner is used to recgonized the user imputs
        
        System.out.println("What is the length? ");
        length = input.nextDouble();
        
        System.out.println("What is the width? ");
        width = input.nextDouble(); 
        
        feet = 12 / (length + width); //The method here is dividing both varibales by stringing them together to get the feet and inches
        inches = 12 % (length * width);
        
        System.out.println("The length and width of the object is " + feet + " ft tall and " + inches + " wide.");
   }
    
}

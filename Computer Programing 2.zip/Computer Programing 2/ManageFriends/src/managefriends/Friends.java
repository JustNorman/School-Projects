package managefriends;
/*
Author: Montell N.
Date: 1/27/21
*/
public class Friends {
    private String firstName; //On line 7 and 8 I used two string varibles that'll be used later in the static varible in line 33
    private String lastName;
    
    public static int totalFriends = 0; //Static varible is used to count how many friends I have
    
    
    //Constructor
    public Friends(String fName, String lName){
        firstName = fName;
        lastName = lName;
        
        totalFriends++; //totalFriends = totalFriends + 1
        
        System.out.println("Friend: " + firstName + " " + lastName + " has been added to the list. " + "Friend Number = " + totalFriends + "\n");
        
    }
    
    public void printLastName() { //This method will help print the last name of the person
        System.out.println("The last name is: " + lastName + "\n");
    }
    
    public void printfirstName(){ //Similar to the last line of code this method will print the first name of the user
        System.out.println("The first name is: " + firstName + "\n");
    }
    
    public static void printInformantion(){ //The static function is used to store the string data
        System.out.println("This is a template that stores info about Friends.");
    }
}

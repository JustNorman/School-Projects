/*
Problem Defintion
Create a java project (ManageFriends) that uses two source files: ManageFriends.java and Friends.java.
Friends.java has two private string variables: firstName and lastName and following methods:
Friends(String first, String last) //constructor 
printInformation() // A static method that explains what Friends class does
Author: Montell N.
Date: 1/27/21
 */
package managefriends;

public class ManageFriends {
    
    public static void main(String[] args) {
        Friends friend1 = new Friends("John", "Silver"); //These Friends objects are used to string in the Friends class from the previous program
        Friends friend2 = new Friends("Mia", "Elliot");
        Friends friend3 = new Friends("Graham", "Heather");
        
        friend1.printLastName(); //Lines 19-25 are used to hide the data by using the access modifer
        friend2.printLastName();
        friend3.printLastName();
        
        friend1.printfirstName();
        friend2.printfirstName();
        friend3.printfirstName();
        
        System.out.println("Total number of friends: " + Friends.totalFriends); //By using the Static Varible it took the friend1-3 varibles and string them into one object
        
        Friends.printInformantion();
    }
    
}

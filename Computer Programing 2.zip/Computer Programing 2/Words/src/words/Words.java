/*
Problem Defintion:
Submit all practice problems we discussed during 4/12's lecture. 
Author: Montell N.
Date: 4/7/21
 */
package words;

public class Words {

    public static void main(String[] args) {
        Dictionary webster = new Dictionary(1500, 52500);
        System.out.println("Number of pages: " + webster.getPages());
        System.out.println("Number of definitions: " + webster.getDefinitions());
        System.out.println("Definitions per pages: " + webster.computeRatio());
    }
    
}

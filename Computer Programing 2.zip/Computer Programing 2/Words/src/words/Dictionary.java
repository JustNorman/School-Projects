/*
Problem Defintion:
Submit all practice problems we discussed during 4/12's lecture. 
Author: Montell N.
Date: 4/7/21
 */
package words;

public class Dictionary extends Book {
    //Data Fields
    private int definitions;
    
    //Constructor
    //Sets up the dictionary with the specified number of pages and definitions
    public Dictionary(int numPages, int numDefinitions){
        super(numPages); //Pages = numPages
        definitions = numDefinitions;
    }
    
    //Calculates ratio using both the local and inherited values
    public double computeRatio(){
        return definitions/pages;
    }
    
    //
    public void setDefinitions(int numDefinitions){
        definitions = numDefinitions;
    }
    
    //
    public int getDefinitions(){
        return definitions;
    }
}

/*
Problem Defintion:
Submit all practice problems we discussed during 4/12's lecture. 
Author: Montell N.
Date: 4/7/21
 */
package words;

public class Book {
    //Data Fields
    protected int pages;
    
    //Constructor
    //Sets up the book with specified number of pages
    public Book(int numPages){
        pages = numPages;
    }
    
    //Pages muttator
    public void setPages(int numpages){
        pages = numpages;
    }
    
    //Pages accessor
    public int getPages(){
        return pages;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example03032021;

public class Example03032021 {
    
    public static void main(String[] args) {
        //String myStr = "JSU"
        String myStr = new String("THE JSU");
        System.out.println(myStr);
        
        //String myStr2 = "MIT";
        //String myStr2 = "JSU";
        String myStr2 = myStr;
        
        if(myStr == myStr2){ //Comparing addresses
            System.out.println(myStr + " equals " + myStr2);
        }
        else{
            System.out.println(myStr + " does not equal " + myStr2);
        }
        
        if(myStr.equals(myStr2)){ //Comparing values
            System.out.println(myStr + " equals " + myStr2);
        }
        else{
            System.out.println(myStr + " does not equal " + myStr2);
        }
        
        if(myStr.compareTo(myStr2) == 0){ //Checks the string to see if its equals to the variable
            System.out.println(myStr + " is same as " + myStr2);
        }
        else if(myStr.compareTo(myStr2) > 0){ //Greater than the variable
            System.out.println(myStr + " is greater than " + myStr2);
        }
        else{ //Or less then the variable
            System.out.println(myStr + " is smaller than " + myStr2);
        }
        
        String my_nullString = null;
        
        System.out.println(myStr.substring(0, 3)); //Will print THE from THE JSU
    }
    
}

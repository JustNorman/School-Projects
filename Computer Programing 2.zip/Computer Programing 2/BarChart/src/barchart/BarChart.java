/*
Author: Martell N.
Date: 3/13/22
 */
package barchart;

import java.util.Scanner;

public class BarChart 
{

    public static void main(String[] args) 
    {
        int Art; //Creating class objects
        int Bob;
        int Cal;
        int Dan;
        int Eli;
        
        //Aksing the user input for the score they earned
        Scanner score = new Scanner(System.in);
        System.out.println("Please enter the amount of point scored by Art: ");
        Art = score.nextInt();
        System.out.println("Please enter the amount of point scored by Bob: ");
        Bob = score.nextInt();
        System.out.println("Please enter the amount of point scored by Cal: ");
        Cal = score.nextInt();
        System.out.println("Please enter the amount of point scored by Dan: ");
        Dan = score.nextInt();
        System.out.println("Please enter the amount of point scored by Eli: ");
        Eli = score.nextInt();
        
        //Creating the loop for the score for each player
        System.out.print("Art: ");
        for(int i = 0; i < Art; i++)
        {
            System.out.print("*");
        }
        System.out.print("\nBob: ");
        for(int i = 0; i < Bob; i++)
        {
            System.out.print("*");
        }
        System.out.print("\nCal: ");
        for(int i = 0; i < Cal; i++)
        {
            System.out.print("*");
        }
        System.out.print("\nDan: ");
        for(int i = 0; i < Dan; i++)
        {
            System.out.print("*");
        }
        System.out.print("\nEli: ");
        for(int i = 0; i < Eli; i++)
        {
            System.out.print("*");
        }
    }
    
}

/*
Problem Defintion: 
Create two child classes of Book: Fiction and NonFiction. 
Each must include a setPrice() method that sets the price for all Fiction Books to $24.99 and for all NonFictionBooks to $37.99. 
Write a constructor for each subclass, and include a call to setPrice() within each. 
Author: Montell N.
Date: 4/14/21
 */
package bookarray;

//Child class
public class Fiction extends Book{
    public Fiction(String bookTitle){
        super(bookTitle);
        setBookPrice();
    }
    
    public void setBookPrice(){
        bookPrice = 24.99;
    }
}

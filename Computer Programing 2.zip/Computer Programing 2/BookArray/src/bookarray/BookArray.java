/*
Problem Defintion: 
Write an application named BookArray in which you create an array that holds 10 Books, some Fiction and some NonFiction. 
Using a for loop, display details about all 10 books. Save the file as BookArray.java.
Author: Montell N.
Date: 4/14/21
 */
package bookarray;

public class BookArray {
    
    public static void main(String[] args) {
        //Create an arrary to store 10 Books
        Book books[] = new Book[10];
        
        books[0] = new Fiction("SCP Foundation");
        books[1] = new Fiction("The Thing");
        books[2] = new Fiction("Friday the 13th");
        books[3] = new Fiction("Mad Max");
        books[4] = new Fiction("The Avengers");
        
        books[5] = new NonFiction("Area 51");
        books[6] = new NonFiction("What we know about the Ocean");
        books[7] = new NonFiction("Some ideas left unknown");
        books[8] = new NonFiction("High School Teen Phases");
        books[9] = new NonFiction("Meme");
        
        //Display all details
        for(int i = 0; i < books.length; i++){
            System.out.println(books[i].getBookTitle()+ " costs: $" +books[i].getBookPrice());
        }
    }
    
}

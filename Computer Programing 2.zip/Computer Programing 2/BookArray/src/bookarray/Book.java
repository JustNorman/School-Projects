/*
Problem Defintion: 
Create an abstract class named Book. Include a String field for the book’s title and a double field for the book’s price. 
Within the class, include a constructor that requires the book title, and add two get methods—one that returns the title and one that returns the price. 
Include an abstract method named setPrice(). 
Author: Montell N.
Date: 4/14/21
 */
package bookarray;

//Parent class
abstract class Book {
    protected String bookTitle;
    protected double bookPrice;
    
    public Book(String bookTitle){
        this.bookTitle = bookTitle;
        this.bookPrice = 0.0;
    }

    public String getBookTitle(){
        return bookTitle;
    }

    public double getBookPrice(){
        return bookPrice;
    }

    public abstract void setBookPrice();
}

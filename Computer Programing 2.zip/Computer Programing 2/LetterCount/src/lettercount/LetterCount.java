/*
Problem Defintion
Your program should read a sentence from the user and counts the number of uppercase, lowercase letters, and non-alphabetic characters contained in it. 
Save the file as LetterCount.java
Author: Montell N.
Date: 3/21/21
 */
package lettercount;

import java.util.*;
import java.util.Scanner;

public class LetterCount {
    
    public static void main(String[] args) {
        final int NUMCHARS = 26;
        Scanner input = new Scanner(System.in);
        int[] alBets = new int[NUMCHARS];

        int[] upper = new int[NUMCHARS];
        int[] lower = new int[NUMCHARS];

        char current;   // the current character being processed
        int other = 0;  // counter for non-alphabetics

        System.out.println("Enter a sentence: ");
        String line = input.nextLine();

        //Count the number of each letter occurence
        for(int ch = 0; ch < line.length(); ch++){
            current = line.charAt(ch);
         if(current >= 'A' && current <= 'Z'){
            alBets[current-'A']++;
         }
         else{
            if(current >= 'a' && current <= 'z'){
               alBets[current-'a']++;
            }
            else{
                other++;
            }
         }
        }

        //Print the results
        System.out.println();
        for(int letter=0; letter < upper.length; letter++){
            System.out.print((char)(letter + 'A'));
            System.out.print(": " + upper[letter]);
            System.out.print("\t\t" + (char)(letter + 'a'));
            System.out.println(": " + lower[letter]);
        }
        System.out.println();
        System.out.println("Non-alphabetic characters: " + other);
        
    }
    
}

package edu.jsu.mcis;

import java.awt.EventQueue;

public class Main {

    public static void main(String[] args) {
        
        /* Create Controller */

        DefaultController controller = new DefaultController();
        
        /* Create Model */

        DefaultModel model = new DefaultModel();

        /* Register Model */

        controller.addModel(model);
        
        EventQueue.invokeLater(new Runnable() {
            
            @Override
            public void run() {
                
                /* Create Views */
                
                PrimaryJFrame window1 = new PrimaryJFrame(controller);
                window1.setVisible(true);
                
                SecondaryJFrame window2 = new SecondaryJFrame(controller);
                window2.setLocation(window1.getX() + window1.getWidth(), window1.getY());
                window2.setVisible(true);
                
                /* Register Views */
                
                controller.addView(window1);
                controller.addView(window2);
                
                model.initDefault();
                
            }
            
        });
        
    }
    
}
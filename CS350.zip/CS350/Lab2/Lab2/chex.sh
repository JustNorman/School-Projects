#!/bin/bash

# Check if an argument is provided
if [ $# -ne 1 ]; then
  echo "Usage: chex <script_file>"
  exit 1
fi

# Get the file name from the argument
file="$1"

# Check if the file exists
if [ ! -e "$file" ]; then
  echo "File '$file' does not exist."
  exit 1
fi

# Make the file executable
chmod +x "$file"

# Check if chmod was successful
if [ $? -eq 0 ]; then
  echo "File '$file' is now executable."
else
  echo "Error: Failed to make '$file' executable."
  exit 1
fi

exit 0

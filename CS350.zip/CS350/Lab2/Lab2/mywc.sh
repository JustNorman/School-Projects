#!/bin/bash

# Check if an argument is provided
if [ $# -ne 1 ]; then
  echo "Usage: mywc <filename>"
  exit 1
fi

# Get the filename from the argument
filename="$1"

# Check if the file exists
if [ ! -e "$filename" ]; then
  echo "File '$filename' does not exist."
  exit 1
fi

# Use the 'wc' command to count lines, words, and characters
lines=$(wc -l < "$filename")
words=$(wc -w < "$filename")
chars=$(wc -c < "$filename")

# Output the results with labels
echo "File: $filename"
echo "Lines: $lines"
echo "Words: $words"
echo "Characters: $chars"

exit 0

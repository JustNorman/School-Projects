#!/bin/bash

# Check if an argument is provided
if [ $# -ne 1 ]; then
  echo "Usage: del <filename>"
  exit 1
fi

# Get the filename from the argument
filename="$1"

# Check if the file exists
if [ ! -e "$filename" ]; then
  echo "File '$filename' does not exist."
  exit 1
fi

# Ask the user for confirmation
read -p "Do you want to delete '$filename'? (Y/N): " choice

# Convert the choice to uppercase
choice=$(echo "$choice" | tr '[:lower:]' '[:upper:]')

# Check if the user confirmed the deletion
if [ "$choice" = "Y" ]; then
  # Delete the file
  rm -f "$filename"
  if [ $? -eq 0 ]; then
    echo "File '$filename' has been deleted."
  else
    echo "Error: Failed to delete '$filename'."
  fi
else
  echo "File '$filename' was not deleted."
fi

exit 0

void delay_by_50us(char cx);
void delay_by_1ms(char cx);
void delay_by_10ms(char cx);
void delay_by_100ms(char cx);
void delay_by_1s(char cx);

#include <C8051F040.H>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "delays.h"
#include "keypad.h"

#define  ZH                 0xFF       /* ZERO (an inaudible high-frequency value) */
#define  ZL                 0xFA
#define  BEEPAH             0xDD       /* BEEP */
#define  BEEPAL             0xC7

#define  KEYPAD_BUFFER_SIZE  0x80

void sys_init(void);
void beep(void);

void main(void)
{

    /* Local Variables and Input Buffer */

    unsigned char xdata keypad_input_buffer[KEYPAD_BUFFER_SIZE];

    /* Initialize Hardware */
    
    sys_init();

    TMR2CF = 0x0A;                     /* select SYSCLK as timer 2 clock; enable T2 output */
    TMR2CN = 0;                        /* disable Timer 2 */

    for(;;) {
    
        SFRPAGE = 0x0F;

        /* Get Keypad Code */

        get_keypad_code(keypad_input_buffer);

        SFRPAGE = UART0_PAGE;

		// INSERT YOUR CODE HERE
        if (strchr(keypad_input_buffer, '*') != NULL)
        {
            /* Activate UART0 SFR page */
            SFRPAGE = UART0_PAGE;

            /* Print the contents of the keypad_input_buffer to the serial port */
            printf("%s\n", keypad_input_buffer);

            /* Deactivate UART0 SFR page */
            SFRPAGE = 0;
        }

    }

}


/* BEEP */

void beep(void) {

    SFRPAGE = 0;

    TMR2H = BEEPAH;                    /* load values for tone */
    TMR2L = BEEPAL;                    /* " */
    RCAP2H = BEEPAH;                   /* " */
    RCAP2L = BEEPAL;                   /* " */

    TR2 = 1;                           /* enable Timer 2 (in auto reload mode) */
    delay_by_100ms(1);                 /* hold tone for 1 ms */
    TR2 = 0;                           /* disable Timer 2 (to change reload value) */

    SFRPAGE = 0x0F;

}


void sys_init(void)
{

    SFRPAGE = CONFIG_PAGE;

    CLKSEL = 0;                        /* Select internal oscillator as SYSCLK */
    OSCICN = 0x83;                     /* " */

    XBR0 = 0xF7;                       /* assign all peripheral signals to port pins */
    XBR1 = 0xFF;                       /* " */
    XBR2 = 0x5D;                       /* " */
    XBR3 = 0x8F;                       /* " */

    WDTCN = 0xDE;                      /* disable watchdog timer */
    WDTCN = 0xAD;                      /* " */

    P7MDOUT = 0xF0;                    /* configure P7^3..P7^0 for input, P7^7..P7^4 for output */
    P6MDOUT = 0xFF;                    /* configure P6 for push/pull */
    P6 = 0;                            /* clear P6 LED array */

    P2MDOUT = 0x80;                    /* enable T2 pin output (P2, pin 7) */
    TMR2CF = 0x0A;                     /* select SYSCLK as timer 2 clock; enable T2 output */
    TMR2CN = 0;                        /* disable Timer 2 */

    SFRPAGE = TMR4_PAGE;               /* Configure UART */

    RCAP4H = 0xFF;                     /* set UART0 baud rate to 19200 */
    RCAP4L = 0xB2;                     /* " */
    TMR4H = 0xFF;                      /* " */
    TMR4L = 0xB2;                      /* " */

    TMR4CF = 0x08;                     /* select SYSCLK as TMR4's clock source */
    TMR4CN = 0x04;                     /* select Timer 4 reload mode */

    SFRPAGE = UART0_PAGE;              /* switch to SFR page 0 */

    SCON0 = 0x50;                      /* UART0 in mode 1, enable reception */
    SSTA0 = 0x0F;                      /* use TMR4 to generate UART0 baud rate */
    TI0 = 1;                           /* get ready to transceive */
    RI0 = 0;                           /* get ready to receive */

    SFRPAGE = 0;

    SPI0CN = 0x01;

}
/*



*/
#include <C8051F040.h>
#include "keypad.h"

/* CONSTANT DEFINITIONS */

#define  KEYPAD_ROWS 0x04
#define  KEYPAD_COLS 0x04
#define  DEBOUNCE_COUNTER 0x12

/* PIN DEFINITIONS */

sbit ROW0 = P7^4;
sbit ROW1 = P7^5;
sbit ROW2 = P7^6;
sbit ROW3 = P7^7;

sbit COL0 = P7^0;
sbit COL1 = P7^1;
sbit COL2 = P7^2;
sbit COL3 = P7^3;

/* KEY DEFINITIONS */

const char KEYS[KEYPAD_ROWS][KEYPAD_COLS] = {

    {'1', '2', '3', 'A'},
    {'4', '5', '6', 'B'},
    {'7', '8', '9', 'C'},
    {'*', '0', '#', 'D'}

};

char kgetkey()
{

    static unsigned char ctr = 0;
    static char prev = -1;
    char result = -1;
    unsigned char r, c;

    for(r = 0; r < KEYPAD_ROWS; ++r)
    {

        ROW0 = ROW1 = ROW2 = ROW3 = 1;

        switch(r)
        {

            case 0:
        
                ROW0 = 0;
    
                for(c = 0; c < KEYPAD_COLS; ++c)
                {

                    switch(c)
                    {

                        case 0:
                            if(COL0 == 0)
                                result = KEYS[r][c];
                            break;

                        case 1:
                            if(COL1 == 0)
                                result = KEYS[r][c];
                            break;

                        case 2:
                            if(COL2 == 0)
                                result = KEYS[r][c];
                            break;

                        case 3:
                            if(COL3 == 0)
                                result = KEYS[r][c];
                            break;

                    }

                }

                break;

            case 1:
        
                ROW1 = 0;
    
                for(c = 0; c < KEYPAD_COLS; ++c)
                {

                    switch(c)
                    {

                        case 0:
                            if(COL0 == 0)
                                result = KEYS[r][c];
                            break;

                        case 1:
                            if(COL1 == 0)
                                result = KEYS[r][c];
                            break;

                        case 2:
                            if(COL2 == 0)
                                result = KEYS[r][c];
                            break;

                        case 3:
                            if(COL3 == 0)
                                result = KEYS[r][c];
                            break;

                    }

                }

                break;

            case 2:
        
                ROW2 = 0;
    
                for(c = 0; c < KEYPAD_COLS; ++c)
                {

                    switch(c)
                    {

                        case 0:
                            if(COL0 == 0)
                                result = KEYS[r][c];
                            break;

                        case 1:
                            if(COL1 == 0)
                                result = KEYS[r][c];
                            break;

                        case 2:
                            if(COL2 == 0)
                                result = KEYS[r][c];
                            break;

                        case 3:
                            if(COL3 == 0)
                                result = KEYS[r][c];
                            break;

                    }

                }

                break;

            case 3:
        
                ROW3 = 0;
    
                for(c = 0; c < KEYPAD_COLS; ++c)
                {

                    switch(c)
                    {

                        case 0:
                            if(COL0 == 0)
                                result = KEYS[r][c];
                            break;

                        case 1:
                            if(COL1 == 0)
                                result = KEYS[r][c];
                            break;

                        case 2:
                            if(COL2 == 0)
                                result = KEYS[r][c];
                            break;

                        case 3:
                            if(COL3 == 0)
                                result = KEYS[r][c];
                            break;

                    }

                }

                break;


        }
    }

    if(prev == result)
    {
        if(ctr < DEBOUNCE_COUNTER)
            ctr++;
    }

    else
        ctr = 0;

    prev = result;
    
    if(ctr == (DEBOUNCE_COUNTER - 1))
    {
        return result;
    }

    else

        return -1;

}

char kgetch()
{

    char key = -1;

    while(key == -1)
        key = kgetkey();

    return key;

}

void get_keypad_code(unsigned char xdata *ptr)
{

    unsigned char key;

    while ( (( key = kgetch() ) != '*') )
    {

        *ptr = key;
        ptr++;
        beep();

    }

    beep();
    *ptr = 0;

}
/*



*/
package edu.jsu.mcis.cs350;

public interface TerminalInterface {
    
    public void send(String command);
    
    public String getTerminalid();
    
}
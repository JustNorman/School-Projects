package edu.jsu.mcis.cs350;

import com.fazecast.jSerialComm.SerialPort;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SerialTerminal implements TerminalInterface, Runnable {

    private final TerminalController terminalController;
    private final String terminalID;
    private final BufferedReader in;
    private final PrintStream out;

    public SerialTerminal(String terminalID, TerminalController terminalController) {
        this.terminalID = terminalID;
        this.terminalController = terminalController;

        // Initialize serial port with the correct settings
        initializeSerialPort(terminalID);

        // Initialize input stream
        InputStream inputStream = getSerialPortInputStream();
        in = new BufferedReader(new InputStreamReader(inputStream));

        // Initialize output stream
        out = System.out; // For simplicity, adjust as needed
    }

    private void initializeSerialPort(String terminalID) {
        SerialPort[] serialPorts = SerialPort.getCommPorts();
        SerialPort selectedPort = null;
        for (SerialPort port : serialPorts) {
            if (port.getSystemPortName().equals(terminalID)) {
                selectedPort = port;
                break;
            }
        }

        if (selectedPort != null) {
            try {
                selectedPort.setBaudRate(19200);
                selectedPort.setNumDataBits(8);
                selectedPort.setNumStopBits(1);
                selectedPort.setParity(SerialPort.NO_PARITY);

                if (selectedPort.openPort()) {
                    Logger.getLogger(SerialTerminal.class.getName()).log(Level.INFO,
                            "Serial port {0} opened successfully.", terminalID);
                } else {
                    Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                            "Failed to open serial port {0}.", terminalID);
                }
            } catch (Exception e) {
                Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                        "Exception while initializing serial port.", e);
            }
        } else {
            Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                    "Serial port {0} not found.", terminalID);
        }
    }

private InputStream getSerialPortInputStream() {
    final PipedInputStream inPipe = new PipedInputStream();
    final PipedOutputStream outPipe;
    
    try {
        outPipe = new PipedOutputStream(inPipe);
        SerialPort.addDataListener(new SerialPortDataListener() {
            @Override
            public int getListeningEvents() {
                return SerialPort.LISTENING_EVENT_DATA_AVAILABLE;
            }

            @Override
            public void serialEvent(SerialPortEvent event) {
                if (event.getEventType() == SerialPort.LISTENING_EVENT_DATA_AVAILABLE) {
                    try {
                        byte[] newData = new byte[SerialPort.bytesAvailable()];
                        int numRead = SerialPort.readBytes(newData, newData.length);
                        outPipe.write(newData, 0, numRead);
                    } catch (IOException e) {
                        Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                                "Exception while reading from serial port.", e);
                    }
                }
            }
        });
    } catch (IOException e) {
        Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                "Exception while creating PipedInputStream/PipedOutputStream.", e);
    }
    
    return inPipe;
}


    public String getTerminalID() {
        return terminalID;
    }

    @Override
    public void send(String output) {
        out.println(output);
    }

    @Override
    public void run() {
        Logger.getLogger(SerialTerminal.class.getName()).log(Level.INFO,
                "Serial Terminal {0} Starting ...", terminalID);

        try {
            while (true) {
                String input = in.readLine();
                if (input != null) {
                    terminalController.processInput(input, this);
                }
            }
        } catch (IOException e) {
            Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                    "IOException in Serial Terminal.", e);
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                Logger.getLogger(SerialTerminal.class.getName()).log(Level.SEVERE,
                        "Exception while closing BufferedReader.", e);
            }
        }
    }

    @Override
    public String getTerminalid() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

package edu.jsu.mcis.cs350;

public class Main {

    public static void main(String[] args) {
        
        try {
            
            TerminalController controller = new TerminalController();
            
            // controller.add(new SerialTerminal("COM3", controller));
            
            controller.add(new ConsoleTerminal("Console Terminal", controller));
            
        }        
        catch (Exception e) { e.printStackTrace(); }
        
    }
    
}

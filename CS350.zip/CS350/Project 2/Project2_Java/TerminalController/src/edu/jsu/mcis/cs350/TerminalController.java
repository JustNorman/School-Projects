package edu.jsu.mcis.cs350;

import java.util.ArrayList;

public class TerminalController {
    
    private static final int MIN_FIELDS = 2;
    
    
    private final ArrayList<Thread> threads;
    private final ArrayList<TerminalInterface> terminals;
        
    public TerminalController() {
        
        terminals = new ArrayList<>();
        threads = new ArrayList<>();
        
    }
    
    
    public void add(TerminalInterface terminal) {
        
        Thread t = new Thread( (Runnable)terminal );
        
        terminals.add(terminal);
        threads.add(t);
        
        t.start();
        
    }
    
    public synchronized void process(String command, TerminalInterface terminal) {
        
        String id = terminal.getTerminalid();
                
        System.err.println("Command Received from " + id + ": " + command);
        
        String[] fields = command.split("#");
        
        if (fields.length >= MIN_FIELDS) {
            
            try {

                EventType event = EventType.values()[ Integer.parseInt(fields[0]) ];
                String badgeid = fields[1];

                switch (event) {
                    case CLOCK_OUT:
                    case CLOCK_IN:
                        terminal.send(event + " Command Processed for Badge #" + badgeid + "!");
                        break;
                    default:
                        terminal.send("Error: Unknown Command!");
                }
                
            }
            catch (NumberFormatException e) {
                System.err.println("ERROR: Invalid Command!");
            } catch (ArrayIndexOutOfBoundsException e) {
                System.err.println("ERROR: Insufficient Fields in Command!");
            } catch (Exception e) {
                System.err.println("ERROR: Unexpected Exception!");
            }
            
        }
        else {
            System.err.println("ERROR: Unknown or Invalid Command!");
        }
        
    }

    void processInput(String input, SerialTerminal aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

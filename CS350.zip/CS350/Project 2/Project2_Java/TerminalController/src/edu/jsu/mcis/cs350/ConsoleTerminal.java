package edu.jsu.mcis.cs350;

import java.io.PrintStream;
import java.util.Scanner;

public class ConsoleTerminal implements Runnable, TerminalInterface {
    
    private final Scanner in;
    private final PrintStream out;
    
    private final TerminalController controller;
    
    private final String terminalid;
    
    /* CONSTRUCTORS */
    
    public ConsoleTerminal(String id, TerminalController controller) {
        
        /* Acquire Input/Output Streams */
        
        this.in = new Scanner(System.in);
        this.out = System.out;
        
        this.terminalid = id;
        this.controller = controller;
        
    }
    
    @Override
    public void send(String output) {
        
        try {
            out.println(output);
        }
        catch (Exception e) { e.printStackTrace(); }
        
    }
    
    @Override
    public void run() {
        
        try {
            
            out.println(terminalid + " Starting ...");
                        
            while(true) {
                
                String line = in.nextLine();
                
                controller.process(line, this);
                
            }
            
        }        
        catch (Exception e) { e.printStackTrace(); }
        
    }
    
    @Override
    public String getTerminalid() {
        return terminalid;
    }
    
}
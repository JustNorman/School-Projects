#include <C8051F040.H>

void delay_by_50us(unsigned char k)
{
    unsigned char i; 
    unsigned char tempage;
    tempage = SFRPAGE;
    SFRPAGE = 0;
    TMOD = 0x11;                       /* configure Timer 0 and 1 to mode 1 */
    CKCON = 0x01;                      /* Timer 0 use system clock divided by 4 as clock source */
    for (i = 0; i < k; i++) {
        TH0 = 0xFE;                    /* place 65236 in TH0:TL0 so it overflows in 50 us */
        TL0 = 0xD4;
        TF0 = 0;
        TR0 = 1;                       /* enable Timer 0 */
        while(!TF0);                   /* wait for 50 us */
        TR0 = 0;                       /* stop Timer 0 */
    }
    SFRPAGE    = tempage;              /* restore original SFRPAGE */
}



void delay_by_1ms(unsigned char k)
{
    unsigned char i,tempage;
    tempage = SFRPAGE;
    SFRPAGE = 0;
    TMOD = 0x11;                       /* configure Timer 0 and 1 to mode 1 */
    CKCON = 0x01;                      /* Timer 0 use system clock divided by 4 as clock source */
    for (i = 0; i < k; i++) {
        TH0 = 0xEB;                    /* place 59410 in TH0:TL0 so it overflows in 1 ms */
        TL0 = 0x12;
        TF0 = 0;
        TR0 = 1;                       /* enable Timer 0 */
        while(!TF0);                   /* wait for 1 ms */
        TR0 = 0;                       /* stop Timer 0 */
    }
    SFRPAGE = tempage;                 /* restore original SFRPAGE */
}



void delay_by_10ms(unsigned char k)
{
    unsigned char i,tempage;
    tempage = SFRPAGE;
    SFRPAGE = 0;
    TMOD = 0x11;                       /* configure Timer 0 and 1 to mode 1 */
    CKCON = 0x0;                       /* Timer 0 use system clock divided by 12 as clock source */
    for (i = 0; i < k; i++) {
        TH0 = 0xB0;                    /* place 45118 in TH0:TL0 so it overflows in 10 ms */
        TL0 = 0x3E;
        TF0 = 0;
        TR0 = 1;                       /* enable Timer 0 */
        while(!TF0);                   /* wait for 10 ms */
        TR0    = 0;                    /* stop Timer 0 */
    }
    SFRPAGE = tempage;                 /* restore original SFRPAGE */
}



void delay_by_100ms(unsigned char k)
{
    unsigned char i,tempage;
    tempage = SFRPAGE;
    SFRPAGE = 0;
    TMOD = 0x11;                       /* configure Timer 0 and 1 to mode 1 */
    CKCON = 0x02;                      /* Timer 0 use system clock divided by 48 as clock source */
    for (i = 0; i < k; i++) {
        TH0 = 0x38;                    /* place 14493 in TH0:TL0 so it overflows in 100 ms */
        TL0 = 0x9D;
        TF0 = 0;
        TR0 = 1;                       /* enable Timer 0 */
        while(!TF0);                   /* wait for 100 ms */
        TR0 = 0;                       /* stop Timer 0 */
    }
    SFRPAGE = tempage;                 /* restore original SFRPAGE */
}



void delay_by_1s(unsigned char k)
{
    unsigned char i,j,tempage;
    tempage = SFRPAGE;
    SFRPAGE = 0;
    TMOD = 0x11;                       /* configure Timer 0 and 1 to mode 1 */
    CKCON = 0x02;                      /* Timer 0 use system clock divided by 48 as clock source */
    for (i = 0; i < k; i++) {
        for (j = 0; j < 10; j++) {
            TH0 = 0x3C;                /* place 15536 in TH0:TL0 so it overflows in 100 ms */
            TL0 = 0xB0;
            TF0 = 0;
            TR0 = 1;                   /* enable Timer 0 */
            while(!TF0);               /* wait for 100 ms */
            TR0 = 0;                   /* stop Timer 0 */
        }
    }
    SFRPAGE = tempage;                 /* restore original SFRPAGE */
}

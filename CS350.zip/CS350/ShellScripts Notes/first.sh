# A simple shell script
cal
date
whoami
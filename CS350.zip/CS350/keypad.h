#ifndef KEYPAD_H
#define KEYPAD_H 1

char kgetkey();
char kgetch();
char kgetchenum();
char kgetchnum();
unsigned int kgetcheint(unsigned char nchars);
void get_keypad_code(unsigned char xdata *ptr);

#endif
